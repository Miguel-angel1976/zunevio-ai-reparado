package com.zunevio.ai.ui.screens

import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zunevio.ai.data.model.ChatHistoryItem
import com.zunevio.ai.data.model.ChatMessage
import com.zunevio.ai.data.model.UserProfile
import com.zunevio.ai.data.repository.ZunevioRepository
import com.zunevio.ai.ui.components.GoldenCrowns
import com.zunevio.ai.ui.theme.*
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    repository: ZunevioRepository,
    userProfile: UserProfile?,
    onOpenPlanes: () -> Unit,
    onOpenReferidos: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var searchWeb by remember { mutableStateOf(false) }
    var autoMemory by remember { mutableStateOf(true) }

    // Motor Text-to-Speech para lectura de respuestas en voz alta
    var tts: TextToSpeech? by remember { mutableStateOf(null) }
    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("es", "ES")
            }
        }
        onDispose {
            tts?.stop()
            tts?.shutdown()
        }
    }

    // Reconocimiento de voz para dictar mensajes
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spokenText.isNullOrBlank()) {
            inputText = spokenText
        }
    }

    val onSendMessage: (String) -> Unit = { query ->
        val text = query.trim()
        if (text.isNotEmpty() && !isLoading) {
            val userMsg = ChatMessage(role = "user", content = text)
            messages = messages + userMsg
            inputText = ""
            isLoading = true

            coroutineScope.launch {
                listState.animateScrollToItem(messages.size)
                try {
                    val historyItems = messages.takeLast(10).map {
                        ChatHistoryItem(role = it.role, content = it.content)
                    }
                    val response = repository.sendChatMessage(
                        message = text,
                        history = historyItems,
                        searchWeb = searchWeb,
                        autoMemory = autoMemory
                    )
                    val assistantMsg = ChatMessage(
                        role = "assistant",
                        content = response.reply,
                        sources = response.sources ?: emptyList()
                    )
                    messages = messages + assistantMsg
                } catch (e: Exception) {
                    if (e is kotlinx.coroutines.CancellationException) throw e
                    val errorMsg = ChatMessage(
                        role = "assistant",
                        content = "No se pudo conectar con el servidor: ${e.localizedMessage ?: "Error de red"}. Por favor verifica tu conexión."
                    )
                    messages = messages + errorMsg
                } finally {
                    isLoading = false
                    listState.animateScrollToItem(messages.size)
                }
            }
        }
    }

    Scaffold(
        containerColor = SpaceBlack,
        bottomBar = {
            // Barra inferior de entrada de texto
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SpaceDeepBlue)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // Toggles: Búsqueda Web y Memoria
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = searchWeb,
                        onClick = { searchWeb = !searchWeb },
                        label = { Text(if (searchWeb) "🌐 Google Web Activa" else "🌐 Búsqueda Web", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ZunevioBlue.copy(alpha = 0.3f),
                            selectedLabelColor = ZunevioCyan
                        )
                    )
                    FilterChip(
                        selected = autoMemory,
                        onClick = { autoMemory = !autoMemory },
                        label = { Text("🧠 Memoria Privada", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ZunevioBlue.copy(alpha = 0.3f),
                            selectedLabelColor = ZunevioCyan
                        )
                    )
                }

                // Campo de texto con micro y botón enviar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Botón Micrófono
                    IconButton(
                        onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla para dictar a ZUNEVIO AI")
                            }
                            speechLauncher.launch(intent)
                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voz",
                            tint = ZunevioLightCyan
                        )
                    }

                    // Input
                    TextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Escribe tu consulta o pide una tarea...", color = TextSlate500, fontSize = 13.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(CardBackground)
                            .border(1.dp, CardBorder, RoundedCornerShape(24.dp)),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = CardBackground,
                            unfocusedContainerColor = CardBackground,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                            unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                        ),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Botón Enviar
                    IconButton(
                        onClick = { onSendMessage(inputText) },
                        enabled = inputText.isNotBlank() && !isLoading,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (inputText.isNotBlank() && !isLoading)
                                    Brush.linearGradient(listOf(ZunevioBlue, ZunevioCyan))
                                else
                                    Brush.linearGradient(listOf(TextSlate500, TextSlate500))
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = "Enviar",
                            tint = TextWhite
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(SpaceBlack)
        ) {
            if (messages.isEmpty()) {
                // Pantalla de Bienvenida cuando no hay mensajes (idéntica a la web)
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "ZUNEVIO AI",
                            color = TextWhite,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Asistente IA online gratis con 20 créditos diarios",
                            color = TextSlate300,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                        )
                    }

                    // Tarjeta 1: Prompt de sugerencia
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clickable {
                                    onSendMessage("¿Cómo puedes ayudarme hoy como ZUNEVIO AI? Explícame tus capacidades principales.")
                                },
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = ZunevioCyan)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("¿En qué puedo ayudarte hoy?", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                                Text(
                                    "Asistente de inteligencia artificial de alto rendimiento con memoria contextual y búsqueda web.",
                                    color = TextSlate300,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }

                    // Tarjeta 2: Planes con Coronas Doradas
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clickable { onOpenPlanes() },
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ZunevioBlue.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                GoldenCrowns()
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Planes y Capacidad de ZUNEVIO AI", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("200 créditos • Plan Premium de alta velocidad", color = CrownGoldLight, fontSize = 12.sp)
                                Button(
                                    onClick = onOpenPlanes,
                                    modifier = Modifier.padding(top = 8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = ZunevioBlue)
                                ) {
                                    Text("Ver Planes y Créditos", color = TextWhite, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Tarjeta 3: Referidos y ganar créditos
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clickable { onOpenReferidos() },
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("🎁 Comparte ZUNEVIO AI y gana créditos", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    "Invita a tus amigos y recibe 20 créditos permanentes por cada nuevo usuario.",
                                    color = TextSlate300,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                // Lista de Mensajes
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    items(messages) { msg ->
                        val isUser = msg.role == "user"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .widthIn(max = 320.dp)
                                    .clip(
                                        RoundedCornerShape(
                                            topStart = 16.dp,
                                            topEnd = 16.dp,
                                            bottomStart = if (isUser) 16.dp else 4.dp,
                                            bottomEnd = if (isUser) 4.dp else 16.dp
                                        )
                                    )
                                    .background(
                                        if (isUser)
                                            Brush.linearGradient(listOf(ZunevioBlue, Color(0xFF0044CC)))
                                        else
                                            Brush.linearGradient(listOf(CardBackground, SpaceDeepBlue))
                                    )
                                    .border(
                                        1.dp,
                                        if (isUser) ZunevioCyan.copy(alpha = 0.3f) else CardBorder,
                                        RoundedCornerShape(16.dp)
                                    )
                                    .padding(14.dp)
                            ) {
                                Column {
                                    Text(
                                        text = msg.content,
                                        color = TextWhite,
                                        fontSize = 14.sp,
                                        lineHeight = 20.sp
                                    )

                                    // Botón para escuchar por altavoz (Text-to-Speech)
                                    if (!isUser) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            IconButton(
                                                onClick = {
                                                    tts?.speak(msg.content, TextToSpeech.QUEUE_FLUSH, null, msg.id)
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.VolumeUp,
                                                    contentDescription = "Leer en voz alta",
                                                    tint = ZunevioCyan,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (isLoading) {
                        item {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = ZunevioCyan,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("ZUNEVIO AI procesando respuesta...", color = TextSlate400, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

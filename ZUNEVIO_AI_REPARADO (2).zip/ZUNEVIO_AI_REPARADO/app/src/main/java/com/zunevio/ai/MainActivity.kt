package com.zunevio.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.google.firebase.auth.FirebaseAuth
import com.zunevio.ai.data.model.UserProfile
import com.zunevio.ai.data.repository.ZunevioRepository
import com.zunevio.ai.ui.components.BottomNavBar
import com.zunevio.ai.ui.components.Screen
import com.zunevio.ai.ui.components.TopBar
import com.zunevio.ai.ui.screens.*
import com.zunevio.ai.ui.theme.SpaceBlack
import com.zunevio.ai.ui.theme.ZunevioAITheme
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val repository by lazy { ZunevioRepository() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ZunevioAITheme {
                val coroutineScope = rememberCoroutineScope()
                var currentRoute by remember { mutableStateOf(Screen.Chat.route) }
                val auth = remember { FirebaseAuth.getInstance() }
                var currentUser by remember { mutableStateOf(auth.currentUser) }

                // Escucha reactiva de cambios de autenticación
                DisposableEffect(auth) {
                    val authListener = FirebaseAuth.AuthStateListener { fbAuth ->
                        currentUser = fbAuth.currentUser
                    }
                    auth.addAuthStateListener(authListener)
                    onDispose {
                        auth.removeAuthStateListener(authListener)
                    }
                }

                // Iniciar sesión anónima como invitado si no hay sesión activa previa
                LaunchedEffect(Unit) {
                    if (currentUser == null) {
                        try {
                            val user = repository.signInAnonymously()
                            if (user != null) {
                                currentUser = user
                            }
                        } catch (e: Exception) {
                            if (e is CancellationException) throw e
                            android.util.Log.e("ZUNEVIO_AI", "Aviso gestionado iniciando sesión anónima en arranque: ${e.message}", e)
                        }
                    }
                }

                // Perfil de usuario en tiempo real desde Firestore
                val userProfile by remember(currentUser?.uid) {
                    val uid = currentUser?.uid
                    if (!uid.isNullOrBlank()) {
                        repository.getUserProfileFlow(uid)
                    } else {
                        flowOf<UserProfile?>(null)
                    }
                }.collectAsState(initial = null)

                Scaffold(
                    containerColor = SpaceBlack,
                    topBar = {
                        TopBar(
                            userProfile = userProfile,
                            onOpenCesta = { currentRoute = Screen.Cesta.route },
                            onOpenAgenda = { currentRoute = Screen.Agenda.route },
                            onOpenPlanes = { currentRoute = Screen.Planes.route },
                            onOpenProfile = { currentRoute = Screen.Perfil.route }
                        )
                    },
                    bottomBar = {
                        BottomNavBar(
                            currentRoute = currentRoute,
                            onNavigate = { currentRoute = it }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(SpaceBlack)
                    ) {
                        val uid = currentUser?.uid ?: ""
                        when (currentRoute) {
                            Screen.Chat.route -> ChatScreen(
                                repository = repository,
                                userProfile = userProfile,
                                onOpenPlanes = { currentRoute = Screen.Planes.route },
                                onOpenReferidos = { currentRoute = Screen.Referidos.route }
                            )
                            Screen.Memoria.route -> MemoriaScreen(
                                repository = repository,
                                uid = uid
                            )
                            Screen.Fotos.route -> PhotosScreen(
                                repository = repository,
                                userProfile = userProfile,
                                onOpenPlanes = { currentRoute = Screen.Planes.route }
                            )
                            Screen.Cesta.route -> CestaScreen(
                                repository = repository,
                                uid = uid
                            )
                            Screen.Agenda.route -> AgendaScreen(
                                repository = repository,
                                uid = uid
                            )
                            Screen.Planes.route -> PlanesScreen(
                                repository = repository,
                                userProfile = userProfile
                            )
                            Screen.Referidos.route -> ReferidosScreen(
                                userProfile = userProfile
                            )
                            Screen.Perfil.route -> ProfileScreen(
                                userProfile = userProfile,
                                onSignOut = {
                                    auth.signOut()
                                    coroutineScope.launch {
                                        try {
                                            currentUser = repository.signInAnonymously()
                                        } catch (e: Exception) {
                                            if (e is CancellationException) throw e
                                            android.util.Log.e("ZUNEVIO_AI", "Error gestionado en cierre de sesión: ${e.message}")
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

# ==============================================================================
# Reglas ProGuard / R8 justificadas para ZUNEVIO AI Android (Release)
# ==============================================================================

# 1. Metadatos de reflexión y trazas legibles en Google Play Console
# Signature/InnerClasses/EnclosingMethod son requeridos por Gson y Retrofit para tipos genéricos.
# SourceFile y LineNumberTable permiten obtener trazas reales (con mapping.txt).
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# 2. Preservación de nombres de excepciones de Firebase (evita ofuscación opaca como L2.i)
-keepnames class com.google.firebase.FirebaseException
-keepnames class com.google.firebase.auth.FirebaseAuthException
-keepnames class com.google.firebase.firestore.FirebaseFirestoreException
-keep class com.google.firebase.concurrent.CustomThreadFactory { *; }

# 3. Modelos de datos y serialización Gson (com.zunevio.ai.data.model)
# Necesario porque Gson accede a los campos mediante reflexión en tiempo de ejecución.
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
    @com.google.gson.annotations.Expose <fields>;
}
-keep class com.zunevio.ai.data.model.** { *; }

# 4. Interfaz Retrofit y cliente OkHttp (com.zunevio.ai.data.api.ZunevioApiService)
# Retrofit genera proxies dinámicos inspeccionando anotaciones @POST y parámetros en runtime.
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations
-keep interface com.zunevio.ai.data.api.ZunevioApiService { *; }
-keepclassmembers interface * {
    @retrofit2.http.* <methods>;
}
-dontwarn okhttp3.**
-dontwarn retrofit2.**
-dontwarn javax.annotation.**

# 5. ServiceLoader de Kotlin Coroutines (MainDispatcherFactory / CoroutineExceptionHandler)
-keepclassmembers class kotlinx.coroutines.internal.MainDispatcherFactory {
    public <init>();
}
-keepclassmembers class kotlinx.coroutines.CoroutineExceptionHandler {
    public <init>();
}
-dontwarn kotlinx.coroutines.**

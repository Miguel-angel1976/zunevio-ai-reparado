var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_node_fs = __toESM(require("node:fs"), 1);
var import_node_crypto = __toESM(require("node:crypto"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_stripe = __toESM(require("stripe"), 1);
var import_genai = require("@google/genai");
var import_vite = require("vite");
import_dotenv.default.config();
var PORT = 3e3;
var HOST = "0.0.0.0";
var DEFAULT_SYSTEM_INSTRUCTION = `Eres ZUNEVIO AI, un asistente de inteligencia artificial profesional, avanzado, tecnol\xF3gico y riguroso.
Tu tono es elegante, preciso, claro y altamente competente.
Responde de forma estructurada, con excelente formato y claridad t\xE9cnica.`;
async function startServer() {
  const app = (0, import_express.default)();
  app.disable("x-powered-by");
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    next();
  });
  app.use(
    import_express.default.json({
      limit: "25mb",
      verify: (req, _res, buf) => {
        req.rawBody = buf;
      }
    })
  );
  class SlidingWindowRateLimiter {
    constructor(windowMs, maxRequests) {
      this.requests = /* @__PURE__ */ new Map();
      this.windowMs = windowMs;
      this.maxRequests = maxRequests;
      setInterval(() => {
        const now = Date.now();
        for (const [key, timestamps] of this.requests.entries()) {
          const valid = timestamps.filter((t) => now - t < this.windowMs);
          if (valid.length === 0) {
            this.requests.delete(key);
          } else {
            this.requests.set(key, valid);
          }
        }
      }, 3e5).unref();
    }
    check(key) {
      const now = Date.now();
      const timestamps = (this.requests.get(key) || []).filter((t) => now - t < this.windowMs);
      if (timestamps.length >= this.maxRequests) {
        const oldest = timestamps[0];
        const resetSeconds = Math.max(1, Math.ceil((oldest + this.windowMs - now) / 1e3));
        return { allowed: false, remaining: 0, resetSeconds };
      }
      timestamps.push(now);
      this.requests.set(key, timestamps);
      return {
        allowed: true,
        remaining: this.maxRequests - timestamps.length,
        resetSeconds: Math.ceil(this.windowMs / 1e3)
      };
    }
  }
  const chatRateLimiter = new SlidingWindowRateLimiter(6e4, 60);
  const memoryRateLimiter = new SlidingWindowRateLimiter(6e4, 40);
  function getClientIp(req) {
    const forwarded = req.headers["x-forwarded-for"];
    if (typeof forwarded === "string") {
      return forwarded.split(",")[0].trim();
    }
    return req.socket.remoteAddress || "127.0.0.1";
  }
  function sanitizeErrorMessage(rawMessage) {
    if (!rawMessage) return "Error interno en el procesamiento de la solicitud.";
    let str = typeof rawMessage === "string" ? rawMessage : String(rawMessage);
    str = str.replace(/AIzaSy[A-Za-z0-9_-]{33}/g, "[REDACTED_API_KEY]");
    str = str.replace(/\/[\w.-]+(\/[\w.-]+)+/g, "[PATH]");
    return str.slice(0, 350);
  }
  app.get("/api/health", (_req, res) => {
    const hasApiKey = Boolean(process.env.GEMINI_API_KEY);
    res.json({
      status: "ok",
      app: "ZUNEVIO AI",
      version: "1.0.0",
      block: 8,
      primaryModel: "gemini-3.8-flash",
      fallbackModels: ["gemini-3.1-flash-lite", "gemini-flash-latest"],
      multimodal: true,
      searchGrounding: true,
      advancedMemory: true,
      geminiConfigured: hasApiKey,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  function retrieveRelevantMemories(userQuery, memories, maxMemories = 3) {
    if (!memories || !Array.isArray(memories) || memories.length === 0 || !userQuery) {
      return { selectedMemories: [], usedMemoryIds: [], formattedContext: "" };
    }
    const normalizedQuery = userQuery.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const queryTokens = new Set(normalizedQuery.split(/\W+/).filter((t) => t.length > 2));
    const scored = memories.map((mem) => {
      const normContent = (mem.content || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      const normKeywords = (mem.keywords || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      const memTokens = new Set([...normContent.split(/\W+/), ...normKeywords.split(/\W+/)].filter((t) => t.length > 2));
      let matches = 0;
      for (const token of queryTokens) {
        if (memTokens.has(token)) {
          matches++;
        }
      }
      const importance = Math.min(Math.max(mem.importance || 3, 1), 5);
      const categoryWeight = mem.category === "instruction" ? 0.4 : mem.category === "preference" ? 0.3 : 0.1;
      const score = matches + importance * 0.1 + categoryWeight;
      return {
        memory: mem,
        matches,
        score
      };
    });
    const relevant = scored.filter((item) => item.matches > 0 || item.memory.category === "instruction" && (item.memory.importance || 3) >= 4).sort((a, b) => b.score - a.score).slice(0, maxMemories).map((item) => item.memory);
    if (relevant.length === 0) {
      return { selectedMemories: [], usedMemoryIds: [], formattedContext: "" };
    }
    const formattedLines = relevant.map((m) => `- [${m.category.toUpperCase()}]: ${m.content}`);
    const formattedContext = `

[MEMORIA RELEVANTE DEL USUARIO - Recuperada selectivamente por pertinencia]:
${formattedLines.join("\n")}
(Aplica estos recuerdos de forma sutil y natural si resultan \xFAtiles para la solicitud actual, sin forzar menciones innecesarias)`;
    return {
      selectedMemories: relevant,
      usedMemoryIds: relevant.map((m) => m.id),
      formattedContext
    };
  }
  let firebaseAppConfig = {};
  try {
    const cfgPath = import_path.default.join(process.cwd(), "firebase-applet-config.json");
    if (import_node_fs.default.existsSync(cfgPath)) {
      firebaseAppConfig = JSON.parse(import_node_fs.default.readFileSync(cfgPath, "utf8"));
    }
  } catch (e) {
    console.warn("[ZUNEVIO AI Server] Could not read firebase-applet-config.json:", e);
  }
  const FIREBASE_PROJECT_ID = firebaseAppConfig.projectId || "gen-lang-client-0353306290";
  const FIRESTORE_DATABASE_ID = firebaseAppConfig.firestoreDatabaseId || "ai-studio-zunevioai-182aba20-f8d9-4947-9a4a-855259ee53b9";
  const FIRESTORE_DOCS_URL = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents`;
  let cachedGooglePublicCerts = {
    keys: {},
    expiresAt: 0
  };
  async function getGooglePublicCerts() {
    const now = Date.now();
    if (cachedGooglePublicCerts.expiresAt > now && Object.keys(cachedGooglePublicCerts.keys).length > 0) {
      return cachedGooglePublicCerts.keys;
    }
    try {
      const res = await fetch("https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com");
      if (!res.ok) {
        throw new Error(`HTTP ${res.status} al obtener certificados p\xFAblicos de Firebase`);
      }
      const cacheControl = res.headers.get("cache-control") || "";
      const maxAgeMatch = cacheControl.match(/max-age=(\d+)/);
      const maxAge = maxAgeMatch ? parseInt(maxAgeMatch[1], 10) : 3600;
      const certs = await res.json();
      cachedGooglePublicCerts = {
        keys: certs,
        expiresAt: now + maxAge * 1e3
      };
      return certs;
    } catch (err) {
      console.error("[ZUNEVIO AI Auth] Error fetching Google public certs:", err);
      if (Object.keys(cachedGooglePublicCerts.keys).length > 0) {
        return cachedGooglePublicCerts.keys;
      }
      throw err;
    }
  }
  function verifyFirebaseJwt(idToken, certs) {
    try {
      const parts = idToken.split(".");
      if (parts.length !== 3) {
        console.warn("[ZUNEVIO AI Auth] Formato de token inv\xE1lido (no contiene 3 partes JWT).");
        return null;
      }
      let header;
      let payload;
      try {
        header = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
        payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
      } catch {
        console.warn("[ZUNEVIO AI Auth] Error al parsear cabecera o payload JSON del token.");
        return null;
      }
      if (header.alg !== "RS256" || !header.kid) {
        console.warn(`[ZUNEVIO AI Auth] Algoritmo no soportado o falta kid: alg=${header?.alg}, kid=${header?.kid}`);
        return null;
      }
      const cert = certs[header.kid];
      if (!cert) {
        console.warn(`[ZUNEVIO AI Auth] Certificado no encontrado para kid: ${header.kid}`);
        return null;
      }
      const verifier = import_node_crypto.default.createVerify("RSA-SHA256");
      verifier.update(`${parts[0]}.${parts[1]}`);
      let isValidSig = verifier.verify(cert, parts[2], "base64url");
      if (!isValidSig) {
        try {
          const b64 = parts[2].replace(/-/g, "+").replace(/_/g, "/");
          const padded = b64.padEnd(b64.length + (4 - b64.length % 4) % 4, "=");
          const verifier2 = import_node_crypto.default.createVerify("RSA-SHA256");
          verifier2.update(`${parts[0]}.${parts[1]}`);
          isValidSig = verifier2.verify(cert, padded, "base64");
        } catch {
        }
      }
      if (!isValidSig) {
        console.warn("[ZUNEVIO AI Auth] Firma criptogr\xE1fica del token no v\xE1lida con la clave p\xFAblica de Google.");
        return null;
      }
      const now = Math.floor(Date.now() / 1e3);
      if (payload.exp && payload.exp < now) {
        console.warn(`[ZUNEVIO AI Auth] Token expirado: exp=${payload.exp}, now=${now}`);
        return null;
      }
      if (payload.iat && payload.iat > now + 300) {
        console.warn(`[ZUNEVIO AI Auth] Token emitido en el futuro: iat=${payload.iat}, now=${now}`);
        return null;
      }
      const allowedAudiences = [
        FIREBASE_PROJECT_ID,
        "gen-lang-client-0353306290",
        "test-aistudio-firebase-182aba20",
        firebaseAppConfig.projectId
      ].filter(Boolean);
      if (!allowedAudiences.includes(payload.aud)) {
        console.warn(`[ZUNEVIO AI Auth] Audiencia del token no coincide: aud='${payload.aud}', permitidas=${allowedAudiences.join(",")}`);
        return null;
      }
      if (payload.iss !== `https://securetoken.google.com/${payload.aud}`) {
        console.warn(`[ZUNEVIO AI Auth] Issuer del token no v\xE1lido: iss='${payload.iss}'`);
        return null;
      }
      if (!payload.sub || typeof payload.sub !== "string") {
        console.warn("[ZUNEVIO AI Auth] Sub (UID) de usuario ausente en el token.");
        return null;
      }
      const isAnonymous = payload.firebase?.sign_in_provider === "anonymous";
      return { uid: payload.sub, email: payload.email, isAnonymous };
    } catch (err) {
      console.warn("[ZUNEVIO AI Auth] Error en verifyFirebaseJwt:", err?.message || err);
      return null;
    }
  }
  async function authenticateRequest(req) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.warn('[ZUNEVIO AI Auth] Petici\xF3n rechazada: Cabecera Authorization ausente o no tiene formato "Bearer <token>".');
      return null;
    }
    const token = authHeader.slice(7).trim();
    if (!token) {
      console.warn("[ZUNEVIO AI Auth] Petici\xF3n rechazada: Token Bearer vac\xEDo.");
      return null;
    }
    try {
      const certs = await getGooglePublicCerts();
      const verified = verifyFirebaseJwt(token, certs);
      if (!verified) return null;
      return { ...verified, idToken: token };
    } catch (err) {
      console.warn("[ZUNEVIO AI Auth] Error en authenticateRequest:", err?.message || err);
      return null;
    }
  }
  class UserConcurrencyCoordinator {
    constructor() {
      this.activeLocks = /* @__PURE__ */ new Map();
    }
    async runExclusive(userId, fn) {
      const existing = this.activeLocks.get(userId) || Promise.resolve();
      let release = () => {
      };
      const nextLock = new Promise((res) => {
        release = res;
      });
      this.activeLocks.set(userId, existing.then(() => nextLock).catch(() => nextLock));
      await existing.catch(() => {
      });
      try {
        return await fn();
      } finally {
        release();
        if (this.activeLocks.get(userId) === nextLock) {
          this.activeLocks.delete(userId);
        }
      }
    }
  }
  const userCoordinator = new UserConcurrencyCoordinator();
  const serverCreditLedger = /* @__PURE__ */ new Map();
  function parseFirestoreFields(fields) {
    if (!fields || typeof fields !== "object") return {};
    const result = {};
    for (const [key, val] of Object.entries(fields)) {
      if (!val || typeof val !== "object") continue;
      const v = val;
      if ("stringValue" in v) result[key] = v.stringValue;
      else if ("integerValue" in v) result[key] = parseInt(v.integerValue, 10);
      else if ("doubleValue" in v) result[key] = parseFloat(v.doubleValue);
      else if ("booleanValue" in v) result[key] = Boolean(v.booleanValue);
      else if ("mapValue" in v) result[key] = parseFirestoreFields(v.mapValue?.fields);
      else if ("nullValue" in v) result[key] = null;
    }
    return result;
  }
  const STRIPE_DATA_DIR = import_path.default.join(process.cwd(), ".data");
  const STRIPE_STORE_FILE = import_path.default.join(STRIPE_DATA_DIR, "stripe_store.json");
  function loadStripeStore() {
    try {
      if (!import_node_fs.default.existsSync(STRIPE_DATA_DIR)) {
        import_node_fs.default.mkdirSync(STRIPE_DATA_DIR, { recursive: true });
      }
      if (import_node_fs.default.existsSync(STRIPE_STORE_FILE)) {
        const raw = import_node_fs.default.readFileSync(STRIPE_STORE_FILE, "utf8");
        const parsed = JSON.parse(raw);
        return {
          processedEvents: parsed.processedEvents || {},
          userBillings: parsed.userBillings || {},
          customerToUser: parsed.customerToUser || {},
          subscriptionToUser: parsed.subscriptionToUser || {}
        };
      }
    } catch (err) {
      console.warn("[ZUNEVIO AI Stripe] Error reading stripe_store.json, using defaults:", err);
    }
    return {
      processedEvents: {},
      userBillings: {},
      customerToUser: {},
      subscriptionToUser: {}
    };
  }
  function saveStripeStore(data) {
    try {
      if (!import_node_fs.default.existsSync(STRIPE_DATA_DIR)) {
        import_node_fs.default.mkdirSync(STRIPE_DATA_DIR, { recursive: true });
      }
      const tmpFile = `${STRIPE_STORE_FILE}.tmp.${Date.now()}`;
      import_node_fs.default.writeFileSync(tmpFile, JSON.stringify(data, null, 2), "utf8");
      import_node_fs.default.renameSync(tmpFile, STRIPE_STORE_FILE);
    } catch (err) {
      console.error("[ZUNEVIO AI Stripe] Error persisting stripe_store.json:", err);
    }
  }
  function getStripeBillingForUser(userId) {
    const store = loadStripeStore();
    return store.userBillings[userId] || null;
  }
  async function fetchServerUserProfile(uid, idToken) {
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const defaultProfile = {
      uid,
      plan: "free",
      dailyMessageCount: 0,
      dailyMessageResetDate: today,
      totalMessagesSent: 0,
      referralCreditsBalance: 0,
      purchasedCreditsBalance: 0
    };
    const defaultStripe = getStripeBillingForUser(uid);
    if (defaultStripe) {
      if (defaultStripe.plan === "premium") defaultProfile.plan = "premium";
      if (typeof defaultStripe.purchasedCreditsBalance === "number") {
        defaultProfile.purchasedCreditsBalance = Math.max(0, defaultStripe.purchasedCreditsBalance);
      }
    }
    const docUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(uid)}`;
    try {
      const headers = {};
      if (idToken) {
        headers["Authorization"] = `Bearer ${idToken}`;
      }
      const res = await fetch(docUrl, { headers });
      if (res.status === 404) return defaultProfile;
      if (!res.ok) {
        console.warn(`[ZUNEVIO AI Server] Failed to fetch Firestore user ${uid}: HTTP ${res.status}`);
        return defaultProfile;
      }
      const data = await res.json();
      const fields = parseFirestoreFields(data.fields);
      const profile = {
        uid,
        plan: fields.plan === "premium" ? "premium" : "free",
        dailyMessageCount: typeof fields.dailyMessageCount === "number" ? fields.dailyMessageCount : 0,
        dailyMessageResetDate: typeof fields.dailyMessageResetDate === "string" ? fields.dailyMessageResetDate : today,
        totalMessagesSent: typeof fields.totalMessagesSent === "number" ? fields.totalMessagesSent : 0,
        referralCreditsBalance: typeof fields.referralCreditsBalance === "number" ? Math.max(0, fields.referralCreditsBalance) : 0,
        purchasedCreditsBalance: typeof fields.purchasedCreditsBalance === "number" ? Math.max(0, fields.purchasedCreditsBalance) : 0,
        aiImagesFreeUsed: typeof fields.aiImagesFreeUsed === "number" ? Math.max(0, fields.aiImagesFreeUsed) : 0,
        aiImagesPurchasedBalance: typeof fields.aiImagesPurchasedBalance === "number" ? Math.max(0, fields.aiImagesPurchasedBalance) : 0
      };
      if (profile.dailyMessageResetDate !== today) {
        profile.dailyMessageCount = 0;
        profile.dailyMessageResetDate = today;
      }
      const stripeBilling = getStripeBillingForUser(uid);
      if (stripeBilling) {
        if (stripeBilling.plan === "premium") {
          profile.plan = "premium";
        }
        if (typeof stripeBilling.purchasedCreditsBalance === "number") {
          profile.purchasedCreditsBalance = Math.max(profile.purchasedCreditsBalance, stripeBilling.purchasedCreditsBalance);
        }
      }
      return profile;
    } catch (err) {
      console.error("[ZUNEVIO AI Server] Error connecting to Firestore for user profile:", err);
      return defaultProfile;
    }
  }
  function calculateWordsCredits(text) {
    if (!text || typeof text !== "string") return 0;
    const trimmed = text.trim();
    if (!trimmed) return 0;
    const words = trimmed.split(/\s+/).filter(Boolean).length;
    if (words === 0) return 0;
    return Math.ceil(words / 50);
  }
  function clampResponseToCredits(text, maxCredits) {
    const maxWords = Math.max(50, maxCredits * 50);
    const words = (text || "").trim().split(/\s+/).filter(Boolean);
    if (words.length === 0) {
      return { text: text || "", creditsConsumed: 0 };
    }
    const rawCredits = Math.ceil(words.length / 50);
    if (rawCredits <= maxCredits) {
      return { text, creditsConsumed: rawCredits };
    }
    const trimmedWords = words.slice(0, maxWords);
    let clamped = trimmedWords.join(" ");
    if (!/[.!?]$/.test(clamped)) {
      clamped += "...";
    }
    const finalCredits = Math.min(maxCredits, Math.ceil(trimmedWords.length / 50));
    return { text: clamped, creditsConsumed: finalCredits };
  }
  async function syncCreditStateToFirestore(uid, idToken, dailyCount, dailyResetDate, totalSent, referralCreditsBalance, purchasedCreditsBalance) {
    let patchUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(uid)}?updateMask.fieldPaths=dailyMessageCount&updateMask.fieldPaths=dailyMessageResetDate&updateMask.fieldPaths=totalMessagesSent&updateMask.fieldPaths=updatedAt`;
    const fieldsPayload = {
      dailyMessageCount: { integerValue: String(dailyCount) },
      dailyMessageResetDate: { stringValue: dailyResetDate },
      totalMessagesSent: { integerValue: String(totalSent) },
      updatedAt: { stringValue: (/* @__PURE__ */ new Date()).toISOString() }
    };
    if (typeof referralCreditsBalance === "number") {
      patchUrl += "&updateMask.fieldPaths=referralCreditsBalance";
      fieldsPayload.referralCreditsBalance = { integerValue: String(referralCreditsBalance) };
    }
    if (typeof purchasedCreditsBalance === "number") {
      patchUrl += "&updateMask.fieldPaths=purchasedCreditsBalance";
      fieldsPayload.purchasedCreditsBalance = { integerValue: String(purchasedCreditsBalance) };
    }
    try {
      const headers = { "Content-Type": "application/json" };
      if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
      await fetch(patchUrl, {
        method: "PATCH",
        headers,
        body: JSON.stringify({ fields: fieldsPayload })
      });
    } catch (err) {
      console.warn("[ZUNEVIO AI Server] Failed to sync credits to Firestore:", err);
    }
  }
  async function atomicCreditReservation(uid, idToken) {
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    let ledgerEntry = serverCreditLedger.get(uid);
    if (!ledgerEntry || ledgerEntry.dailyResetDate !== today || Date.now() - ledgerEntry.lastSync > 6e4) {
      const dbProfile = await fetchServerUserProfile(uid, idToken);
      ledgerEntry = {
        dailyCount: dbProfile.dailyMessageResetDate === today ? dbProfile.dailyMessageCount : 0,
        dailyResetDate: today,
        totalSent: dbProfile.totalMessagesSent,
        plan: dbProfile.plan,
        referralCreditsBalance: dbProfile.referralCreditsBalance,
        purchasedCreditsBalance: dbProfile.purchasedCreditsBalance,
        lastSync: Date.now()
      };
      serverCreditLedger.set(uid, ledgerEntry);
    }
    if (ledgerEntry.plan === "premium") {
      return {
        allowed: true,
        dailyCount: ledgerEntry.dailyCount,
        dailyLimit: 500,
        remainingCredits: 500,
        maxAllowedCredits: 20,
        referralCreditsBalance: ledgerEntry.referralCreditsBalance || 0,
        purchasedCreditsBalance: ledgerEntry.purchasedCreditsBalance || 0,
        consumedFrom: "none"
      };
    }
    const dailyLimit = 20;
    const currentUsage = ledgerEntry.dailyCount;
    const dailyAvailable = Math.max(0, dailyLimit - currentUsage);
    const referralAvailable = Math.max(0, ledgerEntry.referralCreditsBalance || 0);
    const purchasedAvailable = Math.max(0, ledgerEntry.purchasedCreditsBalance || 0);
    const totalAvailable = dailyAvailable + referralAvailable + purchasedAvailable;
    if (totalAvailable <= 0) {
      return {
        allowed: false,
        reason: `Has alcanzado el l\xEDmite de cr\xE9ditos disponibles. Los 20 cr\xE9ditos gratuitos diarios se renuevan autom\xE1ticamente a las 00:00 UTC (1 cr\xE9dito = hasta 50 palabras de respuesta).`,
        dailyCount: currentUsage,
        dailyLimit,
        remainingCredits: 0,
        maxAllowedCredits: 0,
        referralCreditsBalance: 0,
        purchasedCreditsBalance: 0,
        consumedFrom: "none"
      };
    }
    let consumedFrom = "daily";
    if (dailyAvailable > 0) {
      ledgerEntry.dailyCount += 1;
      consumedFrom = "daily";
    } else if (referralAvailable > 0) {
      ledgerEntry.referralCreditsBalance = Math.max(0, ledgerEntry.referralCreditsBalance - 1);
      consumedFrom = "referral";
    } else if (purchasedAvailable > 0) {
      ledgerEntry.purchasedCreditsBalance = Math.max(0, ledgerEntry.purchasedCreditsBalance - 1);
      consumedFrom = "purchased";
    }
    ledgerEntry.lastSync = Date.now();
    const remainingTotal = Math.max(0, dailyLimit - ledgerEntry.dailyCount) + (ledgerEntry.referralCreditsBalance || 0) + (ledgerEntry.purchasedCreditsBalance || 0);
    return {
      allowed: true,
      dailyCount: ledgerEntry.dailyCount,
      dailyLimit,
      remainingCredits: remainingTotal,
      maxAllowedCredits: totalAvailable,
      referralCreditsBalance: ledgerEntry.referralCreditsBalance,
      purchasedCreditsBalance: ledgerEntry.purchasedCreditsBalance,
      consumedFrom
    };
  }
  async function finalizeCreditUsage(uid, idToken, actualCreditsConsumed, initialConsumedFrom) {
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const ledgerEntry = serverCreditLedger.get(uid);
    if (!ledgerEntry) {
      return {
        newCount: 0,
        remaining: 20,
        dailyLimit: 20,
        referralCreditsBalance: 0,
        purchasedCreditsBalance: 0
      };
    }
    if (ledgerEntry.plan === "premium") {
      return {
        newCount: ledgerEntry.dailyCount,
        remaining: 500,
        dailyLimit: 500,
        referralCreditsBalance: ledgerEntry.referralCreditsBalance || 0,
        purchasedCreditsBalance: ledgerEntry.purchasedCreditsBalance || 0
      };
    }
    const dailyLimit = 20;
    if (actualCreditsConsumed === 0) {
      if (initialConsumedFrom === "daily") {
        ledgerEntry.dailyCount = Math.max(0, ledgerEntry.dailyCount - 1);
      } else if (initialConsumedFrom === "referral") {
        ledgerEntry.referralCreditsBalance = Math.min(40, (ledgerEntry.referralCreditsBalance || 0) + 1);
      } else if (initialConsumedFrom === "purchased") {
        ledgerEntry.purchasedCreditsBalance = (ledgerEntry.purchasedCreditsBalance || 0) + 1;
      }
      ledgerEntry.lastSync = Date.now();
      await syncCreditStateToFirestore(
        uid,
        idToken,
        ledgerEntry.dailyCount,
        today,
        ledgerEntry.totalSent,
        ledgerEntry.referralCreditsBalance,
        ledgerEntry.purchasedCreditsBalance
      );
    } else if (actualCreditsConsumed === 1) {
      ledgerEntry.totalSent += 1;
      ledgerEntry.lastSync = Date.now();
      await syncCreditStateToFirestore(
        uid,
        idToken,
        ledgerEntry.dailyCount,
        today,
        ledgerEntry.totalSent,
        ledgerEntry.referralCreditsBalance,
        ledgerEntry.purchasedCreditsBalance
      );
    } else if (actualCreditsConsumed > 1) {
      let extraCredits = actualCreditsConsumed - 1;
      const dailyAvailable = Math.max(0, dailyLimit - ledgerEntry.dailyCount);
      const takeDaily = Math.min(extraCredits, dailyAvailable);
      ledgerEntry.dailyCount += takeDaily;
      extraCredits -= takeDaily;
      if (extraCredits > 0) {
        const referralAvailable = Math.max(0, ledgerEntry.referralCreditsBalance || 0);
        const takeReferral = Math.min(extraCredits, referralAvailable);
        ledgerEntry.referralCreditsBalance = Math.max(0, ledgerEntry.referralCreditsBalance - takeReferral);
        extraCredits -= takeReferral;
      }
      if (extraCredits > 0) {
        const purchasedAvailable = Math.max(0, ledgerEntry.purchasedCreditsBalance || 0);
        const takePurchased = Math.min(extraCredits, purchasedAvailable);
        ledgerEntry.purchasedCreditsBalance = Math.max(0, ledgerEntry.purchasedCreditsBalance - takePurchased);
        extraCredits -= takePurchased;
      }
      ledgerEntry.totalSent += actualCreditsConsumed;
      ledgerEntry.lastSync = Date.now();
      await syncCreditStateToFirestore(
        uid,
        idToken,
        ledgerEntry.dailyCount,
        today,
        ledgerEntry.totalSent,
        ledgerEntry.referralCreditsBalance,
        ledgerEntry.purchasedCreditsBalance
      );
    }
    const remaining = Math.max(0, dailyLimit - ledgerEntry.dailyCount) + (ledgerEntry.referralCreditsBalance || 0) + (ledgerEntry.purchasedCreditsBalance || 0);
    return {
      newCount: ledgerEntry.dailyCount,
      remaining,
      dailyLimit,
      referralCreditsBalance: ledgerEntry.referralCreditsBalance || 0,
      purchasedCreditsBalance: ledgerEntry.purchasedCreditsBalance || 0
    };
  }
  async function refundReservedCredit(uid, idToken, consumedFrom) {
    if (consumedFrom === "none") return;
    const ledgerEntry = serverCreditLedger.get(uid);
    if (!ledgerEntry || ledgerEntry.plan === "premium") return;
    if (consumedFrom === "daily") {
      ledgerEntry.dailyCount = Math.max(0, ledgerEntry.dailyCount - 1);
    } else if (consumedFrom === "referral") {
      ledgerEntry.referralCreditsBalance = Math.min(40, (ledgerEntry.referralCreditsBalance || 0) + 1);
    } else if (consumedFrom === "purchased") {
      ledgerEntry.purchasedCreditsBalance = (ledgerEntry.purchasedCreditsBalance || 0) + 1;
    }
    ledgerEntry.lastSync = Date.now();
  }
  const REFERRALS_DATA_DIR = import_path.default.join(process.cwd(), "data");
  const REFERRALS_STORE_FILE = import_path.default.join(REFERRALS_DATA_DIR, "referrals_store.json");
  function loadReferralsStore() {
    try {
      if (!import_node_fs.default.existsSync(REFERRALS_DATA_DIR)) {
        import_node_fs.default.mkdirSync(REFERRALS_DATA_DIR, { recursive: true });
      }
      if (import_node_fs.default.existsSync(REFERRALS_STORE_FILE)) {
        const raw = import_node_fs.default.readFileSync(REFERRALS_STORE_FILE, "utf8");
        const parsed = JSON.parse(raw);
        return {
          validations: parsed.validations || {},
          inviterCounts: parsed.inviterCounts || {},
          registeredCodes: parsed.registeredCodes || {}
        };
      }
    } catch (err) {
      console.warn("[Referrals Store] Error al leer archivo persistente de referidos:", err);
    }
    return { validations: {}, inviterCounts: {}, registeredCodes: {} };
  }
  function saveReferralsStore(data) {
    try {
      if (!import_node_fs.default.existsSync(REFERRALS_DATA_DIR)) {
        import_node_fs.default.mkdirSync(REFERRALS_DATA_DIR, { recursive: true });
      }
      const tmpFile = `${REFERRALS_STORE_FILE}.tmp.${Date.now()}`;
      import_node_fs.default.writeFileSync(tmpFile, JSON.stringify(data, null, 2), "utf8");
      import_node_fs.default.renameSync(tmpFile, REFERRALS_STORE_FILE);
    } catch (err) {
      console.error("[Referrals Store] Error cr\xEDtico al persistir archivo de referidos:", err);
    }
  }
  function generateUserReferralCode(userId) {
    const cleanId = (userId || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    const suffix = cleanId.slice(0, 6).padEnd(6, "X");
    return `ZUN-${suffix}`;
  }
  const referralValidationRateLimiter = new SlidingWindowRateLimiter(6e4, 20);
  app.post("/api/referrals/validate", async (req, res) => {
    try {
      const clientIp = getClientIp(req);
      const rateCheck = referralValidationRateLimiter.check(clientIp);
      if (!rateCheck.allowed) {
        return res.status(429).json({
          success: false,
          error: "Demasiadas solicitudes de verificaci\xF3n de referidos. Por favor int\xE9ntalo m\xE1s tarde."
        });
      }
      const authResult = await authenticateRequest(req);
      if (!authResult || !authResult.uid) {
        return res.status(401).json({
          success: false,
          error: "No autorizado. Se requiere inicio de sesi\xF3n con token de Firebase v\xE1lido."
        });
      }
      if (authResult.isAnonymous) {
        return res.status(400).json({
          success: false,
          error: "Para validar una invitaci\xF3n, es necesario registrarse con una cuenta de Google."
        });
      }
      const verifiedUserId = authResult.uid;
      const verifiedIdToken = authResult.idToken;
      const rawCode = req.body?.referralCode;
      if (!rawCode || typeof rawCode !== "string") {
        return res.status(400).json({
          success: false,
          error: "C\xF3digo de referido no proporcionado."
        });
      }
      const cleanCode = rawCode.trim().toUpperCase();
      if (!/^[A-Z0-9-]{4,32}$/.test(cleanCode)) {
        return res.status(400).json({
          success: false,
          error: "El formato del c\xF3digo de referido no es v\xE1lido."
        });
      }
      return await userCoordinator.runExclusive(verifiedUserId, async () => {
        const myOwnReferralCode = generateUserReferralCode(verifiedUserId);
        if (cleanCode === myOwnReferralCode) {
          return res.status(400).json({
            success: false,
            error: "No puedes referirte a ti mismo ni canjear tu propio c\xF3digo de invitaci\xF3n."
          });
        }
        const checkValidationUrl = `${FIRESTORE_DOCS_URL}/referralValidations/${encodeURIComponent(verifiedUserId)}`;
        try {
          const checkValRes = await fetch(checkValidationUrl, {
            headers: { Authorization: `Bearer ${verifiedIdToken}` }
          });
          if (checkValRes.ok) {
            return res.status(400).json({
              success: false,
              error: "Ya has canjeado una invitaci\xF3n anteriormente. Solo se permite un canje por usuario."
            });
          }
        } catch (checkErr) {
          console.warn("[Referidos Server] Error verificando validaci\xF3n previa en Firestore:", checkErr);
        }
        let inviterUid = null;
        try {
          const codeDocUrl = `${FIRESTORE_DOCS_URL}/referralCodes/${encodeURIComponent(cleanCode)}`;
          const codeRes = await fetch(codeDocUrl, {
            headers: { Authorization: `Bearer ${verifiedIdToken}` }
          });
          if (codeRes.ok) {
            const codeDoc = await codeRes.json();
            const fields = parseFirestoreFields(codeDoc.fields);
            if (fields.ownerUid && typeof fields.ownerUid === "string") {
              inviterUid = fields.ownerUid;
            }
          }
        } catch (codeErr) {
          console.warn("[Referidos Server] Error consultando directorio referralCodes en Firestore:", codeErr);
        }
        if (!inviterUid) {
          try {
            const store = loadReferralsStore();
            const registered = store.registeredCodes[cleanCode];
            if (registered && registered.ownerUid) {
              inviterUid = registered.ownerUid;
            }
          } catch (storeLookupErr) {
            console.warn("[Referidos Server] Error consultando store local de c\xF3digos:", storeLookupErr);
          }
        }
        if (!inviterUid) {
          try {
            const directUserUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(cleanCode)}`;
            const directUserRes = await fetch(directUserUrl, {
              headers: { Authorization: `Bearer ${verifiedIdToken}` }
            });
            if (directUserRes.ok) {
              inviterUid = cleanCode;
            }
          } catch {
          }
        }
        if (!inviterUid) {
          return res.status(404).json({
            success: false,
            error: "El c\xF3digo de invitaci\xF3n no existe o no pertenece a ning\xFAn usuario registrado en ZUNEVIO AI."
          });
        }
        if (inviterUid === verifiedUserId) {
          return res.status(400).json({
            success: false,
            error: "No puedes referirte a ti mismo ni canjear tu propio c\xF3digo de invitaci\xF3n."
          });
        }
        let currentValidReferrals = 0;
        let currentCreditsEarned = 0;
        let currentCreditsBalance = 0;
        try {
          const inviterProfileUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(inviterUid)}`;
          const inviterRes = await fetch(inviterProfileUrl, {
            headers: { Authorization: `Bearer ${verifiedIdToken}` }
          });
          if (!inviterRes.ok) {
            return res.status(404).json({
              success: false,
              error: "El usuario invitante no existe en la base de datos de ZUNEVIO AI."
            });
          }
          const inviterDoc = await inviterRes.json();
          const inviterFields = parseFirestoreFields(inviterDoc.fields);
          if (inviterFields.email && authResult.email && String(inviterFields.email).trim().toLowerCase() === String(authResult.email).trim().toLowerCase()) {
            return res.status(400).json({
              success: false,
              error: "No puedes usar un c\xF3digo de invitaci\xF3n asociado a tu propia cuenta o direcci\xF3n de correo."
            });
          }
          currentValidReferrals = typeof inviterFields.validReferrals === "number" ? inviterFields.validReferrals : 0;
          currentCreditsEarned = typeof inviterFields.referralCreditsEarned === "number" ? inviterFields.referralCreditsEarned : 0;
          currentCreditsBalance = typeof inviterFields.referralCreditsBalance === "number" ? inviterFields.referralCreditsBalance : 0;
        } catch (fetchInviterErr) {
          console.error("[Referidos Server] Error consultando perfil de invitante en Firestore:", fetchInviterErr);
          return res.status(500).json({
            success: false,
            error: "No se pudo verificar el estado del usuario invitante."
          });
        }
        if (currentValidReferrals >= 2 || currentCreditsEarned >= 40) {
          return res.status(400).json({
            success: false,
            error: "El usuario que te invit\xF3 ya ha alcanzado el l\xEDmite m\xE1ximo de 2 referidos v\xE1lidos (40 cr\xE9ditos)."
          });
        }
        const newValidReferrals = Math.min(2, currentValidReferrals + 1);
        const newCreditsEarned = Math.min(40, currentCreditsEarned + 20);
        const newCreditsBalance = Math.min(40, currentCreditsBalance + 20);
        const now = (/* @__PURE__ */ new Date()).toISOString();
        const commitUrl = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents:commit`;
        const writes = [
          // Escritura 1: Crear validación con precondición exists: false
          {
            currentDocument: { exists: false },
            update: {
              name: `projects/${FIREBASE_PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/referralValidations/${verifiedUserId}`,
              fields: {
                referredUserId: { stringValue: verifiedUserId },
                inviterUid: { stringValue: inviterUid },
                referralCode: { stringValue: cleanCode },
                status: { stringValue: "validated" },
                creditsAwarded: { booleanValue: true },
                creditsAwardedAt: { stringValue: now },
                validatedAt: { stringValue: now },
                createdAt: { stringValue: now }
              }
            }
          },
          // Escritura 2: Actualizar perfil del invitante entregando los 20 créditos no caducables
          {
            currentDocument: { exists: true },
            updateMask: {
              fieldPaths: [
                "validReferrals",
                "referralCreditsEarned",
                "referralCreditsBalance",
                "updatedAt"
              ]
            },
            update: {
              name: `projects/${FIREBASE_PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/users/${inviterUid}`,
              fields: {
                validReferrals: { integerValue: String(newValidReferrals) },
                referralCreditsEarned: { integerValue: String(newCreditsEarned) },
                referralCreditsBalance: { integerValue: String(newCreditsBalance) },
                updatedAt: { stringValue: now }
              }
            }
          },
          // Escritura 3: Actualizar perfil del usuario invitado con referredByCode
          {
            updateMask: {
              fieldPaths: ["referredByCode", "updatedAt"]
            },
            update: {
              name: `projects/${FIREBASE_PROJECT_ID}/databases/${FIRESTORE_DATABASE_ID}/documents/users/${verifiedUserId}`,
              fields: {
                referredByCode: { stringValue: cleanCode },
                updatedAt: { stringValue: now }
              }
            }
          }
        ];
        try {
          const commitRes = await fetch(commitUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${verifiedIdToken}`
            },
            body: JSON.stringify({ writes })
          });
          if (!commitRes.ok) {
            const commitErr = await commitRes.json().catch(() => ({}));
            console.error("[Referidos Server] Error en commit at\xF3mico de Firestore:", commitErr);
            return res.status(400).json({
              success: false,
              error: commitErr?.error?.message || "Error al procesar la entrega de cr\xE9ditos en Firestore."
            });
          }
        } catch (commitNetworkErr) {
          console.error("[Referidos Server] Error de conexi\xF3n en commit de Firestore:", commitNetworkErr);
          return res.status(500).json({
            success: false,
            error: "Error de comunicaci\xF3n con la base de datos al entregar los cr\xE9ditos del referido."
          });
        }
        const inviterLedger = serverCreditLedger.get(inviterUid);
        if (inviterLedger) {
          inviterLedger.referralCreditsBalance = newCreditsBalance;
          inviterLedger.lastSync = Date.now();
        }
        try {
          const store = loadReferralsStore();
          store.validations[verifiedUserId] = {
            referredUserId: verifiedUserId,
            inviterUid,
            referralCode: cleanCode,
            status: "validated",
            validatedAt: now,
            creditsAwarded: true,
            creditsAwardedAt: now,
            createdAt: now
          };
          store.inviterCounts[inviterUid] = newValidReferrals;
          saveReferralsStore(store);
        } catch (storeErr) {
          console.warn("[Referidos Server] Advertencia en log local secundario:", storeErr);
        }
        return res.json({
          success: true,
          message: "C\xF3digo de invitaci\xF3n validado con \xE9xito. Se han entregado exactamente 20 cr\xE9ditos no caducables al invitante.",
          referralCode: cleanCode,
          inviterUid,
          status: "validated",
          creditsAwarded: true,
          creditsAwardedAt: now,
          creditsDelivered: 20,
          inviterValidReferrals: newValidReferrals,
          inviterTotalReferralCredits: newCreditsEarned,
          inviterReferralBalance: newCreditsBalance,
          timestamp: now
        });
      });
    } catch (err) {
      console.error("[Referidos Server] Error no controlado en validaci\xF3n de referido:", err);
      return res.status(500).json({
        success: false,
        error: "Error interno del servidor al procesar la validaci\xF3n del referido."
      });
    }
  });
  app.post("/api/share/lookup-partner", async (req, res) => {
    const verified = await authenticateRequest(req);
    if (!verified) {
      return res.status(401).json({
        success: false,
        error: "No autorizado. Se requiere un Firebase ID token v\xE1lido."
      });
    }
    const { partnerCode } = req.body || {};
    if (!partnerCode || typeof partnerCode !== "string") {
      return res.status(400).json({
        success: false,
        error: "Debes proporcionar un c\xF3digo de socio o ID de usuario v\xE1lido."
      });
    }
    const cleanCode = partnerCode.trim().toUpperCase();
    try {
      let partnerUid = null;
      let partnerDisplayName = "Socio ZUNEVIO";
      try {
        const codeUrl = `${FIRESTORE_DOCS_URL}/referralCodes/${encodeURIComponent(cleanCode)}`;
        const codeRes = await fetch(codeUrl, {
          headers: { Authorization: `Bearer ${verified.idToken}` }
        });
        if (codeRes.ok) {
          const codeDoc = await codeRes.json();
          const fields = parseFirestoreFields(codeDoc.fields);
          if (fields.ownerUid) {
            partnerUid = fields.ownerUid;
          }
        }
      } catch (codeErr) {
        console.warn("[Share Partner] Error consultando referralCodes:", codeErr);
      }
      if (!partnerUid && /^[a-zA-Z0-9_-]{10,128}$/.test(partnerCode.trim())) {
        try {
          const userUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(partnerCode.trim())}`;
          const userRes = await fetch(userUrl, {
            headers: { Authorization: `Bearer ${verified.idToken}` }
          });
          if (userRes.ok) {
            partnerUid = partnerCode.trim();
          }
        } catch (userErr) {
          console.warn("[Share Partner] Error consultando users por ID:", userErr);
        }
      }
      if (!partnerUid) {
        return res.status(404).json({
          success: false,
          error: "No se encontr\xF3 ning\xFAn socio registrado con el c\xF3digo ingresado."
        });
      }
      if (partnerUid === verified.uid) {
        return res.status(400).json({
          success: false,
          error: "Ese es tu propio c\xF3digo de usuario. Introduce el c\xF3digo de otro socio de ZUNEVIO."
        });
      }
      try {
        const profileUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(partnerUid)}`;
        const profileRes = await fetch(profileUrl, {
          headers: { Authorization: `Bearer ${verified.idToken}` }
        });
        if (profileRes.ok) {
          const profileDoc = await profileRes.json();
          const fields = parseFirestoreFields(profileDoc.fields);
          if (fields.displayName && typeof fields.displayName === "string") {
            partnerDisplayName = fields.displayName;
          }
        }
      } catch (profErr) {
        console.warn("[Share Partner] Error obteniendo displayName de socio:", profErr);
      }
      return res.json({
        success: true,
        partner: {
          uid: partnerUid,
          code: cleanCode,
          displayName: partnerDisplayName
        }
      });
    } catch (err) {
      console.error("[Share Partner] Error en lookup-partner:", err);
      return res.status(500).json({
        success: false,
        error: "Error interno al consultar el socio en ZUNEVIO AI."
      });
    }
  });
  app.post("/api/share/record-partner-share", async (req, res) => {
    const verified = await authenticateRequest(req);
    if (!verified) {
      return res.status(401).json({
        success: false,
        error: "No autorizado. Se requiere un Firebase ID token v\xE1lido."
      });
    }
    const { partnerUid, partnerCode, partnerName, shareUrl } = req.body || {};
    if (!partnerUid || typeof partnerUid !== "string") {
      return res.status(400).json({
        success: false,
        error: "Identificador de socio no v\xE1lido."
      });
    }
    if (partnerUid === verified.uid) {
      return res.status(400).json({
        success: false,
        error: "No puedes compartir invitaciones contigo mismo."
      });
    }
    try {
      const inviteId = `inv_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const inviteDocUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(verified.uid)}/sharedInvites/${encodeURIComponent(inviteId)}`;
      const inviteData = {
        id: { stringValue: inviteId },
        userId: { stringValue: verified.uid },
        senderUid: { stringValue: verified.uid },
        recipientUid: { stringValue: partnerUid },
        recipientCode: { stringValue: partnerCode || "" },
        recipientName: { stringValue: partnerName || "Socio ZUNEVIO" },
        sharedUrl: { stringValue: shareUrl || "" },
        channel: { stringValue: "partner" },
        createdAt: { stringValue: (/* @__PURE__ */ new Date()).toISOString() }
      };
      const saveRes = await fetch(inviteDocUrl, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${verified.idToken}`
        },
        body: JSON.stringify({ fields: inviteData })
      });
      if (!saveRes.ok) {
        console.warn("[Share Partner] Advertencia guardando sharedInvite en Firestore:", await saveRes.text());
      }
      return res.json({
        success: true,
        message: `Invitaci\xF3n a ZUNEVIO AI registrada para el socio ${partnerName || ""}.`,
        creditsNotice: "Compartir no otorga cr\xE9ditos. Los cr\xE9ditos de referidos solo se obtienen cuando un nuevo usuario real se registra con tu c\xF3digo y es validado en el servidor."
      });
    } catch (err) {
      console.error("[Share Partner] Error registrando compartir con socio:", err);
      return res.status(500).json({
        success: false,
        error: "Error registrando el contenido compartido con el socio."
      });
    }
  });
  app.post("/api/chat", async (req, res) => {
    try {
      const clientIp = getClientIp(req);
      const rateCheck = chatRateLimiter.check(clientIp);
      res.setHeader("X-RateLimit-Limit", "60");
      res.setHeader("X-RateLimit-Remaining", String(rateCheck.remaining));
      if (!rateCheck.allowed) {
        res.setHeader("Retry-After", String(rateCheck.resetSeconds));
        return res.status(429).json({
          error: `Has superado el l\xEDmite de peticiones simult\xE1neas. Por favor espera ${rateCheck.resetSeconds} segundos antes de enviar otro mensaje.`
        });
      }
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY no est\xE1 configurada en las variables de entorno del servidor."
        });
      }
      const authResult = await authenticateRequest(req);
      if (!authResult || !authResult.uid) {
        return res.status(401).json({
          error: "No autorizado. Se requiere un Firebase ID token v\xE1lido en la cabecera Authorization (Bearer <token>)."
        });
      }
      const verifiedUserId = authResult.uid;
      const verifiedIdToken = authResult.idToken;
      return await userCoordinator.runExclusive(verifiedUserId, async () => {
        const reservation = await atomicCreditReservation(verifiedUserId, verifiedIdToken);
        if (!reservation.allowed) {
          return res.status(403).json({
            error: reservation.reason,
            dailyLimitReached: true,
            dailyCount: reservation.dailyCount,
            dailyLimit: reservation.dailyLimit,
            remainingCredits: 0,
            referralCreditsBalance: 0,
            purchasedCreditsBalance: 0
          });
        }
        const { maxAllowedCredits } = reservation;
        let generationSucceeded = false;
        try {
          if (!req.body || typeof req.body !== "object" || Array.isArray(req.body)) {
            await refundReservedCredit(verifiedUserId, verifiedIdToken, reservation.consumedFrom);
            return res.status(400).json({
              error: "Cuerpo de solicitud inv\xE1lido. Se espera un objeto JSON."
            });
          }
          const forbiddenKeys = ["__proto__", "constructor", "prototype"];
          if (Object.keys(req.body).some((k) => forbiddenKeys.includes(k))) {
            await refundReservedCredit(verifiedUserId, verifiedIdToken, reservation.consumedFrom);
            return res.status(400).json({ error: "Par\xE1metros de solicitud no permitidos." });
          }
          const {
            messages,
            model = "gemini-3.8-flash",
            systemInstruction,
            enableSearch = false,
            memories = []
          } = req.body;
          if (!messages || !Array.isArray(messages) || messages.length === 0) {
            await refundReservedCredit(verifiedUserId, verifiedIdToken, reservation.consumedFrom);
            return res.status(400).json({
              error: "Se requiere una lista de mensajes v\xE1lida en la solicitud."
            });
          }
          if (messages.length > 100) {
            await refundReservedCredit(verifiedUserId, verifiedIdToken, reservation.consumedFrom);
            return res.status(400).json({
              error: "La conversaci\xF3n supera el l\xEDmite m\xE1ximo permitido de mensajes por petici\xF3n (100)."
            });
          }
          const sanitizedModel = typeof model === "string" && /^[a-zA-Z0-9_\-\.:]{1,64}$/.test(model.trim()) ? model.trim() : "gemini-3.8-flash";
          const sanitizedSystemInstruction = typeof systemInstruction === "string" ? systemInstruction.slice(0, 8e3) : void 0;
          const sanitizedEnableSearch = Boolean(enableSearch);
          const safeMemories = Array.isArray(memories) ? memories.filter((m) => m && typeof m.id === "string" && typeof m.content === "string").slice(0, 30).map((m) => ({
            id: String(m.id).slice(0, 128),
            content: String(m.content).slice(0, 1e3),
            category: typeof m.category === "string" ? m.category : "context",
            keywords: typeof m.keywords === "string" ? m.keywords.slice(0, 200) : void 0,
            importance: typeof m.importance === "number" ? Math.min(Math.max(m.importance, 1), 5) : 3
          })) : [];
          const lastUserMsg = [...messages].reverse().find((m) => m && (m.role === "user" || !m.role));
          const lastUserText = typeof lastUserMsg?.content === "string" ? lastUserMsg.content : "";
          const memoryRetrieval = retrieveRelevantMemories(lastUserText, safeMemories, 3);
          let effectiveSystemInstruction = (sanitizedSystemInstruction || DEFAULT_SYSTEM_INSTRUCTION) + memoryRetrieval.formattedContext;
          if (maxAllowedCredits < 20) {
            const maxWordsBudget = maxAllowedCredits * 50;
            effectiveSystemInstruction += `

[L\xCDMITE ESTRICTO DE RESPUESTA: El usuario dispone de ${maxAllowedCredits} cr\xE9dito(s) restante(s) (${maxWordsBudget} palabras). Tu respuesta DEBE ser concisa, completa y terminar antes de superar ${maxWordsBudget} palabras. No excedas este tama\xF1o bajo ning\xFAn concepto.]`;
          }
          const ALLOWED_MIME_PREFIXES = [
            "image/",
            "application/pdf",
            "text/",
            "application/json",
            "application/xml",
            "application/javascript",
            "application/typescript"
          ];
          const sanitizedMessages = [];
          for (const msg of messages.slice(-50)) {
            if (!msg || typeof msg !== "object") continue;
            const role = msg.role === "assistant" || msg.role === "model" ? "model" : "user";
            const rawContent = typeof msg.content === "string" ? msg.content.slice(0, 4e4).trim() : "";
            const validAttachments = [];
            if (Array.isArray(msg.attachments)) {
              for (const att of msg.attachments.slice(0, 5)) {
                if (!att || typeof att.data !== "string" || !att.data.trim()) continue;
                const mimeType = typeof att.mimeType === "string" ? att.mimeType.toLowerCase().trim() : "application/octet-stream";
                const isAllowedMime = ALLOWED_MIME_PREFIXES.some((p) => mimeType.startsWith(p) || mimeType === p);
                if (!isAllowedMime) continue;
                const cleanBase64 = att.data.replace(/^data:[^;]+;base64,/, "").trim();
                if (cleanBase64.length === 0 || cleanBase64.length > 2e7) continue;
                if (!/^[A-Za-z0-9+/=\s]+$/.test(cleanBase64.slice(0, 500))) continue;
                validAttachments.push({
                  mimeType,
                  data: cleanBase64,
                  name: typeof att.name === "string" ? att.name.replace(/[^a-zA-Z0-9._\-\s]/g, "").slice(0, 100) : void 0
                });
              }
            }
            if (rawContent.length > 0 || validAttachments.length > 0) {
              sanitizedMessages.push({
                role,
                content: rawContent,
                attachments: validAttachments.length > 0 ? validAttachments : void 0
              });
            }
          }
          if (sanitizedMessages.length === 0) {
            await refundReservedCredit(verifiedUserId, verifiedIdToken, reservation.consumedFrom);
            return res.status(400).json({
              error: "No se encontraron mensajes v\xE1lidos con texto o archivos adjuntos."
            });
          }
          const formattedContents = [];
          for (const msg of sanitizedMessages) {
            const msgParts = [];
            if (msg.attachments && msg.attachments.length > 0) {
              for (const att of msg.attachments) {
                msgParts.push({
                  inlineData: {
                    mimeType: att.mimeType,
                    data: att.data
                  }
                });
              }
            }
            if (msg.content) {
              msgParts.push({ text: msg.content });
            } else if (msg.attachments && msg.attachments.length > 0) {
              msgParts.push({ text: "Por favor analiza con rigor y detalle el contenido del archivo o imagen adjunta." });
            }
            const lastTurn = formattedContents[formattedContents.length - 1];
            if (lastTurn && lastTurn.role === msg.role) {
              lastTurn.parts.push(...msgParts);
            } else {
              formattedContents.push({
                role: msg.role,
                parts: msgParts
              });
            }
          }
          if (formattedContents.length > 0 && formattedContents[0].role !== "user") {
            formattedContents[0].role = "user";
          }
          const ai = new import_genai.GoogleGenAI({
            apiKey,
            httpOptions: {
              headers: {
                "User-Agent": "aistudio-build"
              }
            }
          });
          const requestedModel = typeof model === "string" && model.trim() ? model.trim() : "gemini-3.8-flash";
          let candidateModels;
          if (sanitizedEnableSearch) {
            const searchSupportedModels = ["gemini-3.8-flash", "gemini-flash-latest"];
            if (searchSupportedModels.includes(requestedModel)) {
              candidateModels = Array.from(/* @__PURE__ */ new Set([requestedModel, ...searchSupportedModels]));
            } else {
              candidateModels = searchSupportedModels;
            }
          } else {
            candidateModels = Array.from(/* @__PURE__ */ new Set([
              requestedModel,
              "gemini-3.8-flash",
              "gemini-3.1-flash-lite",
              "gemini-flash-latest"
            ]));
          }
          if (sanitizedEnableSearch) {
            effectiveSystemInstruction += `

[MODO INTERNET Y B\xDASQUEDA WEB EN TIEMPO REAL ACTIVO - GOOGLE SEARCH GROUNDING]:
El usuario ha seleccionado expresamente el Modo Internet / B\xFAsqueda Web en tiempo real.
TIENES ACCESO A LA HERRAMIENTA OFICIAL DE GOOGLE SEARCH (googleSearch).
INSTRUCCIONES OBLIGATORIAS:
1. Realiza b\xFAsquedas web reales antes de responder cuando la consulta lo requiera (informaci\xF3n actual, noticias de \xFAltima hora, clima, cotizaciones, personas, resultados deportivos, eventos recientes o datos verificables).
2. Utiliza estrictamente la informaci\xF3n y los datos encontrados en la b\xFAsqueda web para elaborar una respuesta contrastada, fidedigna, precisa y actualizada.
3. No inventes datos ni simules fuentes inexistentes.
4. Explica con claridad la informaci\xF3n encontrada citando los hechos obtenidos en la b\xFAsqueda web.`;
          }
          let generatedText = "";
          let usedModel = candidateModels[0] || "gemini-3.8-flash";
          let lastError = null;
          let extractedSources = [];
          let extractedSearchQueries = [];
          const tools = sanitizedEnableSearch ? [{ googleSearch: {} }] : void 0;
          const safeMaxTokens = Math.min(4e3, Math.max(sanitizedEnableSearch ? 500 : 100, maxAllowedCredits * 70));
          for (let i = 0; i < candidateModels.length; i++) {
            const currentCandidate = candidateModels[i];
            try {
              usedModel = currentCandidate;
              const response = await ai.models.generateContent({
                model: currentCandidate,
                contents: formattedContents,
                config: {
                  systemInstruction: effectiveSystemInstruction,
                  maxOutputTokens: safeMaxTokens,
                  ...tools ? { tools } : {}
                }
              });
              if (response.text) {
                generatedText = response.text;
                lastError = null;
                const candidate2 = response.candidates?.[0];
                const grounding = candidate2?.groundingMetadata || response.groundingMetadata;
                if (grounding) {
                  if (Array.isArray(grounding.webSearchQueries)) {
                    extractedSearchQueries = grounding.webSearchQueries.filter((q) => typeof q === "string" && q.trim()).map((q) => q.trim());
                  }
                  if (Array.isArray(grounding.groundingChunks)) {
                    const seenUrls = /* @__PURE__ */ new Set();
                    for (const chunk of grounding.groundingChunks) {
                      const web = chunk.web;
                      const uri = web?.uri || web?.url;
                      if (uri && typeof uri === "string" && !seenUrls.has(uri)) {
                        seenUrls.add(uri);
                        let hostname = "";
                        try {
                          hostname = new URL(uri).hostname.replace(/^www\./, "");
                        } catch {
                          hostname = "Web";
                        }
                        extractedSources.push({
                          title: web.title && typeof web.title === "string" && web.title.trim() ? web.title.trim() : hostname,
                          url: uri
                        });
                      }
                    }
                  }
                }
                break;
              }
              const candidate = response.candidates?.[0];
              if (candidate && candidate.finishReason && candidate.finishReason !== "STOP") {
                generatedText = `[Respuesta finalizada con estado: ${candidate.finishReason}]`;
                lastError = null;
                break;
              }
              throw new Error(`El modelo ${currentCandidate} devolvi\xF3 una respuesta vac\xEDa.`);
            } catch (err) {
              lastError = err;
              const errMsg = String(err?.message || "");
              const errStatus = Number(err?.status || err?.response?.status || 0);
              console.warn(`[ZUNEVIO AI] Fallo en modelo ${currentCandidate} (b\xFAsqueda: ${sanitizedEnableSearch}):`, errMsg);
              if (sanitizedEnableSearch && (errStatus === 429 || errMsg.includes("RESOURCE_EXHAUSTED") || errMsg.includes("quota"))) {
                console.info("[ZUNEVIO AI] L\xEDmite de cuota en Google Search Grounding a nivel de proyecto/API key.");
                break;
              }
              const isTransient = errMsg.includes("503") || errMsg.includes("504") || errMsg.includes("502") || errMsg.includes("500") || errMsg.includes("UNAVAILABLE") || errMsg.includes("DEADLINE_EXCEEDED") || errMsg.includes("high demand") || errMsg.includes("overloaded") || errMsg.includes("fetch failed") || errMsg.includes("ECONNRESET") || errMsg.includes("ETIMEDOUT") || errMsg.includes("respuesta vac\xEDa");
              if (!isTransient || i === candidateModels.length - 1) {
                break;
              }
            }
          }
          if (lastError && !generatedText) {
            const errMsg = String(lastError?.message || "");
            const errStatus = Number(lastError?.status || lastError?.response?.status || 0);
            if (sanitizedEnableSearch) {
              await refundReservedCredit(verifiedUserId, verifiedIdToken, reservation.consumedFrom);
              const isQuota = errStatus === 429 || errMsg.includes("RESOURCE_EXHAUSTED") || errMsg.includes("429") || errMsg.includes("quota");
              const userErrorMessage = isQuota ? "El servicio de b\xFAsqueda web en tiempo real ha alcanzado temporalmente el l\xEDmite de cuota disponible en Google AI. Por favor, reintenta en unos instantes o desactiva el Modo Internet si deseas realizar una consulta general." : `No se pudo completar la b\xFAsqueda web en tiempo real (${errMsg || "Error de conexi\xF3n con Google Search"}). Por favor, reintenta la consulta.`;
              return res.status(errStatus >= 400 && errStatus < 600 ? errStatus : 502).json({
                error: userErrorMessage
              });
            }
            throw lastError;
          }
          generationSucceeded = true;
          const { text: clampedText, creditsConsumed } = clampResponseToCredits(generatedText, maxAllowedCredits);
          const usageUpdate = await finalizeCreditUsage(verifiedUserId, verifiedIdToken, creditsConsumed, reservation.consumedFrom);
          return res.json({
            text: clampedText,
            model: usedModel,
            block: 8,
            sources: extractedSources.length > 0 ? extractedSources : void 0,
            searchQueries: extractedSearchQueries.length > 0 ? extractedSearchQueries : void 0,
            usedMemoryIds: memoryRetrieval.usedMemoryIds.length > 0 ? memoryRetrieval.usedMemoryIds : void 0,
            creditsUsed: creditsConsumed,
            remainingCredits: usageUpdate.remaining,
            dailyCount: usageUpdate.newCount,
            dailyLimit: usageUpdate.dailyLimit,
            referralCreditsBalance: usageUpdate.referralCreditsBalance,
            purchasedCreditsBalance: usageUpdate.purchasedCreditsBalance
          });
        } catch (genError) {
          if (!generationSucceeded) {
            await refundReservedCredit(verifiedUserId, verifiedIdToken, reservation.consumedFrom);
          }
          throw genError;
        }
      });
    } catch (error) {
      console.error("[ZUNEVIO AI Server Error]:", error?.message || "Unknown error");
      let cleanErrorMessage = "Error inesperado al comunicarse con Gemini API.";
      if (error?.message) {
        try {
          const parsed = JSON.parse(error.message);
          if (parsed?.error?.message) {
            cleanErrorMessage = parsed.error.message;
          } else {
            cleanErrorMessage = error.message;
          }
        } catch {
          cleanErrorMessage = error.message;
        }
      }
      return res.status(500).json({
        error: sanitizeErrorMessage(cleanErrorMessage)
      });
    }
  });
  app.post("/api/memory/extract", async (req, res) => {
    try {
      const clientIp = getClientIp(req);
      const rateCheck = memoryRateLimiter.check(clientIp);
      res.setHeader("X-RateLimit-Limit", "40");
      res.setHeader("X-RateLimit-Remaining", String(rateCheck.remaining));
      if (!rateCheck.allowed) {
        res.setHeader("Retry-After", String(rateCheck.resetSeconds));
        return res.status(429).json({
          newMemories: [],
          updatedMemories: [],
          reason: `L\xEDmite de peticiones de an\xE1lisis de memoria alcanzado. Espera ${rateCheck.resetSeconds}s.`
        });
      }
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "GEMINI_API_KEY no est\xE1 configurada." });
      }
      if (!req.body || typeof req.body !== "object" || Array.isArray(req.body)) {
        return res.status(400).json({
          newMemories: [],
          updatedMemories: [],
          reason: "Cuerpo de solicitud inv\xE1lido."
        });
      }
      const { userMessage, assistantResponse, existingMemories = [] } = req.body;
      if (!userMessage || typeof userMessage !== "string" || userMessage.trim().length < 4) {
        return res.json({
          newMemories: [],
          updatedMemories: [],
          reason: "El mensaje es demasiado breve o conversacional para extraer memoria duradera."
        });
      }
      const safeUserMsg = userMessage.slice(0, 4e3);
      const safeAssistantResponse = typeof assistantResponse === "string" ? assistantResponse.slice(0, 3e3) : "";
      const safeExistingMemories = Array.isArray(existingMemories) ? existingMemories.filter((m) => m && typeof m.content === "string").slice(0, 25).map((m) => ({
        id: String(m.id || "").slice(0, 128),
        content: String(m.content).slice(0, 300),
        category: String(m.category || "context").slice(0, 30)
      })) : [];
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: { headers: { "User-Agent": "aistudio-build" } }
      });
      const extractionPrompt = `Eres el subsistema de an\xE1lisis de memoria a largo plazo de ZUNEVIO AI.
Tu misi\xF3n es determinar si el usuario ha revelado informaci\xF3n duradera, \xFAtil y de alto valor contextual sobre s\xED mismo, sus preferencias, sus proyectos activos o instrucciones de trabajo permanentes.

INTERCAMBIO RECIENTE:
Usuario: "${safeUserMsg.replace(/"/g, '\\"')}"
Asistente: "${safeAssistantResponse.replace(/"/g, '\\"')}"

RECUERDOS EXISTENTES REGISTRADOS (para evitar duplicados o redundancias):
${JSON.stringify(safeExistingMemories, null, 2)}

REGLAS DE MEMORIA:
1. SOLO extrae preferencias expl\xEDcitas, hechos t\xE9cnicos/profesionales duraderos, detalles de proyectos o directrices permanentes.
2. NUNCA memorices saludos casuales, preguntas gen\xE9ricas transitorias ("\xBFqu\xE9 hora es?", "\xBFqu\xE9 es React?"), o cortes\xEDas ef\xEDmeras.
3. PREVENCI\xD3N DE DUPLICADOS: Si un recuerdo existente ya expresa el mismo hecho o preferencia, NO generes un nuevo recuerdo.
4. ACTUALIZACI\xD3N: Si el usuario contradice o actualiza expl\xEDcitamente un recuerdo existente (ej: "ya no uso JavaScript, ahora solo uso Rust"), indica el id del recuerdo en 'updatedMemories'.
5. Si no hay nada duradero que valga la pena retener, devuelve arrays vac\xEDos.

Responde estrictamente en formato JSON v\xE1lido con este esquema:
{
  "newMemories": [
    {
      "content": "declaraci\xF3n concisa en tercera persona (m\xE1ximo 200 caracteres)",
      "category": "preference" | "fact" | "instruction" | "project" | "context",
      "importance": 1 a 5,
      "keywords": "palabras clave clave1, clave2, clave3"
    }
  ],
  "updatedMemories": [
    {
      "id": "id_del_recuerdo_a_actualizar",
      "content": "nueva redacci\xF3n actualizada",
      "category": "preference" | "fact" | "instruction" | "project" | "context"
    }
  ],
  "reason": "breve justificaci\xF3n t\xE9cnica del an\xE1lisis"
}`;
      const candidateExtractModels = [
        "gemini-3.8-flash",
        "gemini-3.1-flash-lite",
        "gemini-flash-latest"
      ];
      let extractionText = null;
      let lastExtractErr = null;
      for (const mName of candidateExtractModels) {
        try {
          const extraction = await ai.models.generateContent({
            model: mName,
            contents: [{ role: "user", parts: [{ text: extractionPrompt }] }],
            config: {
              responseMimeType: "application/json"
            }
          });
          if (extraction.text) {
            extractionText = extraction.text;
            break;
          }
        } catch (err) {
          lastExtractErr = err;
          console.warn(`[ZUNEVIO AI] Memory extract fallback on ${mName}:`, err?.message || err);
        }
      }
      if (!extractionText) {
        return res.json({
          newMemories: [],
          updatedMemories: [],
          reason: `An\xE1lisis omitido por fallo transitorio: ${sanitizeErrorMessage(lastExtractErr?.message || "Sin respuesta de modelos")}`
        });
      }
      let parsed;
      try {
        parsed = JSON.parse(extractionText);
      } catch {
        return res.json({ newMemories: [], updatedMemories: [], reason: "Error parseando JSON de extracci\xF3n." });
      }
      return res.json({
        newMemories: Array.isArray(parsed?.newMemories) ? parsed.newMemories : [],
        updatedMemories: Array.isArray(parsed?.updatedMemories) ? parsed.updatedMemories : [],
        reason: parsed?.reason || "An\xE1lisis completado."
      });
    } catch (error) {
      console.error("[ZUNEVIO AI Memory Extract Error]:", error?.message || error);
      return res.json({
        newMemories: [],
        updatedMemories: [],
        reason: `An\xE1lisis omitido por fallo transitorio: ${sanitizeErrorMessage(error?.message || "Error")}`
      });
    }
  });
  async function updateServerUserPhotoQuota(uid, updates, idToken) {
    const patchMasks = ["updateMask.fieldPaths=updatedAt"];
    const fieldsPayload = {
      updatedAt: { stringValue: (/* @__PURE__ */ new Date()).toISOString() }
    };
    if (typeof updates.aiImagesFreeUsed === "number") {
      patchMasks.push("updateMask.fieldPaths=aiImagesFreeUsed");
      fieldsPayload.aiImagesFreeUsed = { integerValue: String(updates.aiImagesFreeUsed) };
    }
    if (typeof updates.aiImagesPurchasedBalance === "number") {
      patchMasks.push("updateMask.fieldPaths=aiImagesPurchasedBalance");
      fieldsPayload.aiImagesPurchasedBalance = { integerValue: String(updates.aiImagesPurchasedBalance) };
    }
    const patchUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(uid)}?${patchMasks.join("&")}`;
    const headers = { "Content-Type": "application/json" };
    if (idToken) {
      headers["Authorization"] = `Bearer ${idToken}`;
    }
    try {
      await fetch(patchUrl, {
        method: "PATCH",
        headers,
        body: JSON.stringify({ fields: fieldsPayload })
      });
    } catch (err) {
      console.warn("[ZUNEVIO AI Photos] Aviso actualizando cuota en Firestore:", err);
    }
  }
  app.get("/api/photos/quota", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      if (!verified?.uid) {
        return res.status(401).json({ error: "No autenticado." });
      }
      const profile = await fetchServerUserProfile(verified.uid, verified.idToken);
      const isPremium = profile.plan === "premium";
      const freeUsed = typeof profile.aiImagesFreeUsed === "number" ? profile.aiImagesFreeUsed : 0;
      const freeLimit = 5;
      const freeRemaining = isPremium ? 999999 : Math.max(0, freeLimit - freeUsed);
      const purchasedBalance = typeof profile.aiImagesPurchasedBalance === "number" ? profile.aiImagesPurchasedBalance : 0;
      const canGenerate = isPremium || freeRemaining > 0 || purchasedBalance > 0;
      return res.json({
        isPremium,
        freeUsed,
        freeLimit,
        freeRemaining,
        purchasedBalance,
        canGenerate
      });
    } catch (error) {
      console.error("[ZUNEVIO AI Photos Quota Error]:", error?.message || error);
      return res.status(500).json({ error: "Error consultando cuota de fotos." });
    }
  });
  app.post("/api/photos/generate", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      if (!verified?.uid) {
        return res.status(401).json({ error: "No autenticado. Inicia sesi\xF3n para generar im\xE1genes con IA." });
      }
      const { prompt, aspectRatio = "1:1", stylePreset } = req.body || {};
      if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
        return res.status(400).json({ error: "La descripci\xF3n o prompt para generar la imagen es obligatoria." });
      }
      const cleanPrompt = prompt.trim().slice(0, 2e3);
      const validRatios = ["1:1", "9:16", "16:9", "4:3", "3:4"];
      const chosenRatio = validRatios.includes(aspectRatio) ? aspectRatio : "1:1";
      let finalPrompt = cleanPrompt;
      if (stylePreset && typeof stylePreset === "string" && stylePreset !== "none") {
        finalPrompt = `${cleanPrompt}. Estilo visual: ${stylePreset.trim()}. Alta calidad y definici\xF3n.`;
      }
      return await userCoordinator.runExclusive(verified.uid, async () => {
        const profile = await fetchServerUserProfile(verified.uid, verified.idToken);
        const isPremium = profile.plan === "premium";
        const freeUsed = typeof profile.aiImagesFreeUsed === "number" ? profile.aiImagesFreeUsed : 0;
        const freeLimit = 5;
        const purchasedBalance = typeof profile.aiImagesPurchasedBalance === "number" ? profile.aiImagesPurchasedBalance : 0;
        if (!isPremium && freeUsed >= freeLimit && purchasedBalance <= 0) {
          return res.status(403).json({
            error: "Has alcanzado el l\xEDmite de 5 im\xE1genes gratuitas con IA. Adquiere el Pack de 10 fotos por 4,99 \u20AC o activa ZUNEVIO Premium para generaci\xF3n ilimitada.",
            limitReached: true,
            freeUsed,
            freeLimit,
            purchasedBalance: 0,
            isPremium: false
          });
        }
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
          return res.status(503).json({
            error: "El servicio de generaci\xF3n de im\xE1genes no est\xE1 disponible en este momento. La variable GEMINI_API_KEY debe estar configurada en el servidor."
          });
        }
        const ai = new import_genai.GoogleGenAI({
          apiKey,
          httpOptions: { headers: { "User-Agent": "aistudio-build" } }
        });
        const candidateModels = ["gemini-3.1-flash-image", "gemini-3.1-flash-lite-image"];
        let imageBase64 = null;
        let mimeType = "image/png";
        let lastErr = null;
        for (const mName of candidateModels) {
          try {
            const response = await ai.models.generateContent({
              model: mName,
              contents: finalPrompt,
              config: {
                imageConfig: {
                  aspectRatio: chosenRatio
                }
              }
            });
            if (response.candidates && response.candidates[0]?.content?.parts) {
              for (const part of response.candidates[0].content.parts) {
                if (part.inlineData && part.inlineData.data) {
                  imageBase64 = part.inlineData.data;
                  mimeType = part.inlineData.mimeType || "image/png";
                  break;
                }
              }
            }
            if (imageBase64) break;
          } catch (err) {
            lastErr = err;
            console.warn(`[ZUNEVIO AI Photos] Fallo generando imagen con ${mName}:`, err?.message || err);
          }
        }
        if (!imageBase64) {
          const errMsg = lastErr?.message || "El modelo de IA no pudo generar la imagen para las instrucciones dadas.";
          return res.status(502).json({
            error: sanitizeErrorMessage(errMsg)
          });
        }
        let newFreeUsed = freeUsed;
        let newPurchasedBalance = purchasedBalance;
        if (!isPremium) {
          if (freeUsed < freeLimit) {
            newFreeUsed = freeUsed + 1;
            await updateServerUserPhotoQuota(verified.uid, { aiImagesFreeUsed: newFreeUsed }, verified.idToken);
          } else if (purchasedBalance > 0) {
            newPurchasedBalance = purchasedBalance - 1;
            await updateServerUserPhotoQuota(verified.uid, { aiImagesPurchasedBalance: newPurchasedBalance }, verified.idToken);
          }
        }
        return res.json({
          success: true,
          imageUrl: `data:${mimeType};base64,${imageBase64}`,
          prompt: cleanPrompt,
          aspectRatio: chosenRatio,
          freeUsed: newFreeUsed,
          freeLimit,
          purchasedBalance: newPurchasedBalance,
          isPremium
        });
      });
    } catch (error) {
      console.error("[ZUNEVIO AI Photos Generate Error]:", error?.message || error);
      return res.status(500).json({ error: sanitizeErrorMessage(error?.message || "Error generando imagen con IA.") });
    }
  });
  app.post("/api/photos/edit", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      if (!verified?.uid) {
        return res.status(401).json({ error: "No autenticado. Inicia sesi\xF3n para editar im\xE1genes con IA." });
      }
      const { image, prompt, actionType = "custom" } = req.body || {};
      if (!image || typeof image !== "string") {
        return res.status(400).json({ error: "Se requiere una imagen para editar." });
      }
      if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
        return res.status(400).json({ error: "La instrucci\xF3n de edici\xF3n o cambio a realizar es obligatoria." });
      }
      const cleanPrompt = prompt.trim().slice(0, 2e3);
      let rawBase64 = image;
      let inputMime = "image/jpeg";
      const match = image.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
      if (match) {
        inputMime = match[1];
        rawBase64 = match[2];
      }
      return await userCoordinator.runExclusive(verified.uid, async () => {
        const profile = await fetchServerUserProfile(verified.uid, verified.idToken);
        const isPremium = profile.plan === "premium";
        const freeUsed = typeof profile.aiImagesFreeUsed === "number" ? profile.aiImagesFreeUsed : 0;
        const freeLimit = 5;
        const purchasedBalance = typeof profile.aiImagesPurchasedBalance === "number" ? profile.aiImagesPurchasedBalance : 0;
        if (!isPremium && freeUsed >= freeLimit && purchasedBalance <= 0) {
          return res.status(403).json({
            error: "Has alcanzado el l\xEDmite de 5 im\xE1genes gratuitas con IA. Adquiere el Pack de 10 fotos por 4,99 \u20AC o activa ZUNEVIO Premium para edici\xF3n ilimitada.",
            limitReached: true,
            freeUsed,
            freeLimit,
            purchasedBalance: 0,
            isPremium: false
          });
        }
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
          return res.status(503).json({
            error: "El servicio de edici\xF3n de im\xE1genes no est\xE1 disponible. La variable GEMINI_API_KEY debe estar configurada en el servidor."
          });
        }
        const ai = new import_genai.GoogleGenAI({
          apiKey,
          httpOptions: { headers: { "User-Agent": "aistudio-build" } }
        });
        const candidateModels = ["gemini-3.1-flash-image", "gemini-3.1-flash-lite-image"];
        let imageBase64 = null;
        let mimeType = "image/png";
        let lastErr = null;
        const editInstruction = `Modifica la imagen proporcionada seg\xFAn esta instrucci\xF3n exacta: ${cleanPrompt}. Tipo de operaci\xF3n: ${actionType}. Mant\xE9n alta resoluci\xF3n y coherencia visual con la imagen original.`;
        for (const mName of candidateModels) {
          try {
            const response = await ai.models.generateContent({
              model: mName,
              contents: [
                {
                  inlineData: {
                    data: rawBase64,
                    mimeType: inputMime
                  }
                },
                { text: editInstruction }
              ]
            });
            if (response.candidates && response.candidates[0]?.content?.parts) {
              for (const part of response.candidates[0].content.parts) {
                if (part.inlineData && part.inlineData.data) {
                  imageBase64 = part.inlineData.data;
                  mimeType = part.inlineData.mimeType || "image/png";
                  break;
                }
              }
            }
            if (imageBase64) break;
          } catch (err) {
            lastErr = err;
            console.warn(`[ZUNEVIO AI Photos] Fallo editando imagen con ${mName}:`, err?.message || err);
          }
        }
        if (!imageBase64) {
          const errMsg = lastErr?.message || "El modelo no pudo generar la variaci\xF3n o edici\xF3n de la imagen solicitada.";
          return res.status(502).json({
            error: sanitizeErrorMessage(errMsg)
          });
        }
        let newFreeUsed = freeUsed;
        let newPurchasedBalance = purchasedBalance;
        if (!isPremium) {
          if (freeUsed < freeLimit) {
            newFreeUsed = freeUsed + 1;
            await updateServerUserPhotoQuota(verified.uid, { aiImagesFreeUsed: newFreeUsed }, verified.idToken);
          } else if (purchasedBalance > 0) {
            newPurchasedBalance = purchasedBalance - 1;
            await updateServerUserPhotoQuota(verified.uid, { aiImagesPurchasedBalance: newPurchasedBalance }, verified.idToken);
          }
        }
        return res.json({
          success: true,
          imageUrl: `data:${mimeType};base64,${imageBase64}`,
          prompt: cleanPrompt,
          freeUsed: newFreeUsed,
          freeLimit,
          purchasedBalance: newPurchasedBalance,
          isPremium
        });
      });
    } catch (error) {
      console.error("[ZUNEVIO AI Photos Edit Error]:", error?.message || error);
      return res.status(500).json({ error: sanitizeErrorMessage(error?.message || "Error editando imagen con IA.") });
    }
  });
  app.post("/api/photos/upload-storage", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      if (!verified?.uid) {
        return res.status(401).json({ error: "No autenticado." });
      }
      const { photoId, storagePath, dataUrl } = req.body || {};
      if (!photoId || !dataUrl || typeof dataUrl !== "string") {
        return res.status(400).json({ error: "Datos de imagen o ID no v\xE1lidos." });
      }
      const targetPath = storagePath && typeof storagePath === "string" && storagePath.startsWith(`users/${verified.uid}/`) ? storagePath : `users/${verified.uid}/photos/${photoId}.png`;
      const base64Data = dataUrl.replace(/^data:image\/\w+;base64,/, "");
      const buffer = Buffer.from(base64Data, "base64");
      const bucket = "gen-lang-client-0353306290.firebasestorage.app";
      const uploadUrl = `https://firebasestorage.googleapis.com/v0/b/${encodeURIComponent(bucket)}/o?name=${encodeURIComponent(targetPath)}`;
      const headers = {
        "Content-Type": "image/png"
      };
      if (verified.idToken) {
        headers["Authorization"] = `Bearer ${verified.idToken}`;
      }
      const uploadRes = await fetch(uploadUrl, {
        method: "POST",
        headers,
        body: buffer
      });
      if (!uploadRes.ok) {
        const errText = await uploadRes.text();
        console.warn("[Firebase Storage Server Upload Warning]:", uploadRes.status, errText);
        throw new Error(`Fallo al subir a Firebase Storage (${uploadRes.status})`);
      }
      const uploadData = await uploadRes.json();
      const downloadTokens = uploadData.downloadTokens || "";
      const downloadUrl = `https://firebasestorage.googleapis.com/v0/b/${encodeURIComponent(bucket)}/o/${encodeURIComponent(targetPath)}?alt=media${downloadTokens ? `&token=${downloadTokens}` : ""}`;
      return res.json({
        success: true,
        downloadUrl,
        storagePath: targetPath
      });
    } catch (err) {
      console.error("[Firebase Storage Server Upload Error]:", err);
      return res.status(500).json({
        error: sanitizeErrorMessage(err?.message || "Error al guardar archivo en Firebase Storage")
      });
    }
  });
  app.post("/api/photos/delete-storage", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      if (!verified?.uid) {
        return res.status(401).json({ error: "No autenticado." });
      }
      const { storagePath } = req.body || {};
      if (!storagePath || typeof storagePath !== "string" || !storagePath.startsWith(`users/${verified.uid}/`)) {
        return res.status(400).json({ error: "Ruta de almacenamiento no permitida o inv\xE1lida." });
      }
      const bucket = "gen-lang-client-0353306290.firebasestorage.app";
      const deleteUrl = `https://firebasestorage.googleapis.com/v0/b/${encodeURIComponent(bucket)}/o/${encodeURIComponent(storagePath)}`;
      const headers = {};
      if (verified.idToken) {
        headers["Authorization"] = `Bearer ${verified.idToken}`;
      }
      await fetch(deleteUrl, {
        method: "DELETE",
        headers
      });
      return res.json({ success: true });
    } catch (err) {
      console.warn("[Firebase Storage Server Delete Warning]:", err);
      return res.json({ success: false });
    }
  });
  app.post("/api/files/upload-storage", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      if (!verified?.uid) {
        return res.status(401).json({ error: "No autenticado." });
      }
      const { fileId, fileName, mimeType, dataBase64, storagePath } = req.body || {};
      if (!fileId || !fileName || !dataBase64 || typeof dataBase64 !== "string") {
        return res.status(400).json({ error: "Datos del archivo o identificador no v\xE1lidos." });
      }
      const cleanFileName = String(fileName).replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120);
      const targetPath = storagePath && typeof storagePath === "string" && storagePath.startsWith(`users/${verified.uid}/files/`) ? storagePath : `users/${verified.uid}/files/${fileId}_${cleanFileName}`;
      const rawBase64 = dataBase64.replace(/^data:[^;]+;base64,/, "");
      const buffer = Buffer.from(rawBase64, "base64");
      const bucket = "gen-lang-client-0353306290.firebasestorage.app";
      const uploadUrl = `https://firebasestorage.googleapis.com/v0/b/${encodeURIComponent(bucket)}/o?name=${encodeURIComponent(targetPath)}`;
      const headers = {
        "Content-Type": mimeType || "application/octet-stream"
      };
      if (verified.idToken) {
        headers["Authorization"] = `Bearer ${verified.idToken}`;
      }
      const uploadRes = await fetch(uploadUrl, {
        method: "POST",
        headers,
        body: buffer
      });
      if (!uploadRes.ok) {
        const errText = await uploadRes.text();
        console.warn("[Firebase Storage Server Files Upload Warning]:", uploadRes.status, errText);
        throw new Error(`Fallo al subir a Firebase Storage (${uploadRes.status})`);
      }
      const uploadData = await uploadRes.json();
      const downloadTokens = uploadData.downloadTokens || "";
      const downloadUrl = `https://firebasestorage.googleapis.com/v0/b/${encodeURIComponent(bucket)}/o/${encodeURIComponent(targetPath)}?alt=media${downloadTokens ? `&token=${downloadTokens}` : ""}`;
      return res.json({
        success: true,
        downloadUrl,
        storagePath: targetPath
      });
    } catch (err) {
      console.error("[Firebase Storage Files Upload Error]:", err);
      return res.status(500).json({
        error: sanitizeErrorMessage(err?.message || "Error al almacenar archivo en Firebase Storage")
      });
    }
  });
  app.post("/api/files/delete-storage", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      if (!verified?.uid) {
        return res.status(401).json({ error: "No autenticado." });
      }
      const { storagePath } = req.body || {};
      if (!storagePath || typeof storagePath !== "string" || !storagePath.startsWith(`users/${verified.uid}/files/`)) {
        return res.status(400).json({ error: "Ruta de archivo no permitida o inv\xE1lida." });
      }
      const bucket = "gen-lang-client-0353306290.firebasestorage.app";
      const deleteUrl = `https://firebasestorage.googleapis.com/v0/b/${encodeURIComponent(bucket)}/o/${encodeURIComponent(storagePath)}`;
      const headers = {};
      if (verified.idToken) {
        headers["Authorization"] = `Bearer ${verified.idToken}`;
      }
      await fetch(deleteUrl, {
        method: "DELETE",
        headers
      });
      return res.json({ success: true });
    } catch (err) {
      console.warn("[Firebase Storage Files Delete Warning]:", err);
      return res.json({ success: false });
    }
  });
  let stripeClientInstance = null;
  let lastStripeKey = null;
  function getStripe() {
    const secretKey = process.env.STRIPE_SECRET_KEY;
    if (!secretKey) {
      throw new Error("STRIPE_SECRET_KEY environment variable is required");
    }
    if (!stripeClientInstance || lastStripeKey !== secretKey) {
      stripeClientInstance = new import_stripe.default(secretKey);
      lastStripeKey = secretKey;
    }
    return stripeClientInstance;
  }
  const STRIPE_PRODUCTS_MAP = {
    credits_pack: {
      priceId: "price_1UH78I2QG2ejGGDv05ZSIn9U",
      mode: "payment",
      name: "200 Cr\xE9ditos ZUNEVIO AI (Pago \xFAnico)"
    },
    photos_pack: {
      priceId: "price_1UH78I2QG2ejGGDv05ZSIn9U",
      mode: "payment",
      name: "Pack 10 Fotos con IA ZUNEVIO AI (4,99 \u20AC)"
    },
    premium_subscription: {
      priceId: "price_1UH7AO2QG2ejGGDvzTu3yQtP",
      mode: "subscription",
      name: "Plan Premium ZUNEVIO AI (9,99 \u20AC/mes)"
    }
  };
  async function applyPhotosPackFulfillment(userId, eventId, photosToAdd = 10, description = "Compra de Pack 10 Fotos con IA (4,99 \u20AC)", userEmail, idToken) {
    const store = loadStripeStore();
    const existing = store.userBillings[userId] || {
      userId,
      email: userEmail,
      plan: "free",
      purchasedCreditsBalance: 0,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
      history: []
    };
    if (userEmail && !existing.email) existing.email = userEmail;
    existing.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
    existing.history.push({
      eventId,
      type: "photos_pack",
      amountCredits: photosToAdd,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      description
    });
    store.userBillings[userId] = existing;
    saveStripeStore(store);
    try {
      const userProfile = await fetchServerUserProfile(userId, idToken);
      const currentPurchased = userProfile.aiImagesPurchasedBalance || 0;
      const newBalance = currentPurchased + photosToAdd;
      await updateServerUserPhotoQuota(userId, { aiImagesPurchasedBalance: newBalance }, idToken);
      console.info(`[ZUNEVIO AI Stripe] IDEMPOTENTE: +${photosToAdd} fotos con IA a\xF1adidas al usuario ${userId}. Saldo fotos: ${newBalance}`);
      return { newBalance };
    } catch (fsErr) {
      console.warn("[ZUNEVIO AI Stripe] Aviso sincronizando pack de fotos a Firestore:", fsErr);
      return { newBalance: photosToAdd };
    }
  }
  async function applyCreditsPackFulfillment(userId, eventId, creditsToAdd = 200, description = "Compra de 200 cr\xE9ditos ZUNEVIO AI", userEmail, idToken) {
    const store = loadStripeStore();
    const existing = store.userBillings[userId] || {
      userId,
      email: userEmail,
      plan: "free",
      purchasedCreditsBalance: 0,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
      history: []
    };
    const prevBalance = typeof existing.purchasedCreditsBalance === "number" ? Math.max(0, existing.purchasedCreditsBalance) : 0;
    const newBalance = prevBalance + creditsToAdd;
    existing.purchasedCreditsBalance = newBalance;
    if (userEmail && !existing.email) existing.email = userEmail;
    existing.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
    existing.history.push({
      eventId,
      type: "credits_pack",
      amountCredits: creditsToAdd,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      description
    });
    store.userBillings[userId] = existing;
    saveStripeStore(store);
    const ledger = serverCreditLedger.get(userId);
    if (ledger) {
      ledger.purchasedCreditsBalance = newBalance;
      ledger.lastSync = Date.now();
    }
    console.info(`[ZUNEVIO AI Stripe] IDEMPOTENTE: +${creditsToAdd} cr\xE9ditos a\xF1adidos al usuario ${userId}. Saldo comprado: ${newBalance}`);
    if (idToken) {
      try {
        const patchUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(userId)}?updateMask.fieldPaths=purchasedCreditsBalance&updateMask.fieldPaths=updatedAt`;
        await fetch(patchUrl, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${idToken}`
          },
          body: JSON.stringify({
            fields: {
              purchasedCreditsBalance: { integerValue: String(newBalance) },
              updatedAt: { stringValue: (/* @__PURE__ */ new Date()).toISOString() }
            }
          })
        });
      } catch (err) {
        console.warn("[ZUNEVIO AI Stripe] Aviso no fatal sincronizando cr\xE9ditos comprados a Firestore:", err);
      }
    }
    return { newBalance };
  }
  async function applyPremiumSubscriptionActivation(userId, eventId, customerId, subscriptionId, userEmail, idToken) {
    const store = loadStripeStore();
    const existing = store.userBillings[userId] || {
      userId,
      email: userEmail,
      plan: "free",
      purchasedCreditsBalance: 0,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
      history: []
    };
    existing.plan = "premium";
    if (customerId) existing.stripeCustomerId = customerId;
    if (subscriptionId) existing.stripeSubscriptionId = subscriptionId;
    existing.subscriptionStatus = "active";
    if (userEmail && !existing.email) existing.email = userEmail;
    existing.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
    existing.history.push({
      eventId,
      type: "premium_subscription_activated",
      plan: "premium",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      description: "Suscripci\xF3n Premium ZUNEVIO AI activada"
    });
    if (customerId) store.customerToUser[customerId] = userId;
    if (subscriptionId) store.subscriptionToUser[subscriptionId] = userId;
    store.userBillings[userId] = existing;
    saveStripeStore(store);
    const ledger = serverCreditLedger.get(userId);
    if (ledger) {
      ledger.plan = "premium";
      ledger.lastSync = Date.now();
    }
    console.info(`[ZUNEVIO AI Stripe] IDEMPOTENTE: Plan Premium activado para usuario ${userId}. Customer: ${customerId || "N/A"}, Sub: ${subscriptionId || "N/A"}`);
    if (idToken) {
      try {
        const patchUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(userId)}?updateMask.fieldPaths=plan&updateMask.fieldPaths=updatedAt`;
        await fetch(patchUrl, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${idToken}`
          },
          body: JSON.stringify({
            fields: {
              plan: { stringValue: "premium" },
              updatedAt: { stringValue: (/* @__PURE__ */ new Date()).toISOString() }
            }
          })
        });
      } catch (err) {
        console.warn("[ZUNEVIO AI Stripe] Aviso sincronizando plan premium a Firestore:", err);
      }
    }
  }
  async function applyPremiumSubscriptionCancellation(userId, eventId, reason = "Suscripci\xF3n cancelada o finalizada", idToken) {
    const store = loadStripeStore();
    const existing = store.userBillings[userId];
    if (!existing) return;
    existing.plan = "free";
    existing.subscriptionStatus = "canceled";
    existing.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
    existing.history.push({
      eventId,
      type: "premium_subscription_canceled",
      plan: "free",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      description: reason
    });
    store.userBillings[userId] = existing;
    saveStripeStore(store);
    const ledger = serverCreditLedger.get(userId);
    if (ledger) {
      ledger.plan = "free";
      ledger.lastSync = Date.now();
    }
    console.info(`[ZUNEVIO AI Stripe] IDEMPOTENTE: Plan Premium cancelado/finalizado para usuario ${userId}. Motivo: ${reason}`);
    if (idToken) {
      try {
        const patchUrl = `${FIRESTORE_DOCS_URL}/users/${encodeURIComponent(userId)}?updateMask.fieldPaths=plan&updateMask.fieldPaths=updatedAt`;
        await fetch(patchUrl, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${idToken}`
          },
          body: JSON.stringify({
            fields: {
              plan: { stringValue: "free" },
              updatedAt: { stringValue: (/* @__PURE__ */ new Date()).toISOString() }
            }
          })
        });
      } catch (err) {
        console.warn("[ZUNEVIO AI Stripe] Aviso sincronizando fin de plan premium a Firestore:", err);
      }
    }
  }
  app.post("/api/stripe/create-checkout-session", async (req, res) => {
    try {
      const { planType, successUrl, cancelUrl } = req.body || {};
      if (!planType || !(planType in STRIPE_PRODUCTS_MAP)) {
        return res.status(400).json({
          error: 'Tipo de plan inv\xE1lido. Opciones permitidas: "credits_pack" (200 cr\xE9ditos), "photos_pack" (Pack 10 Fotos) o "premium_subscription" (Premium).'
        });
      }
      const productConfig = STRIPE_PRODUCTS_MAP[planType];
      const verified = await authenticateRequest(req);
      const userId = verified?.uid || (typeof req.body?.userId === "string" ? req.body.userId.trim() : void 0);
      const userEmail = verified?.email || (typeof req.body?.email === "string" ? req.body.email.trim() : void 0);
      const rawOrigin = req.headers.origin || (req.headers.referer ? new URL(req.headers.referer).origin : "");
      const defaultOrigin = process.env.APP_URL || rawOrigin || "http://localhost:3000";
      const cleanOrigin = defaultOrigin.replace(/\/+$/, "");
      const finalSuccessUrl = typeof successUrl === "string" && successUrl.startsWith("http") ? successUrl : `${cleanOrigin}/?payment=success&type=${planType}&session_id={CHECKOUT_SESSION_ID}`;
      const finalCancelUrl = typeof cancelUrl === "string" && cancelUrl.startsWith("http") ? cancelUrl : `${cleanOrigin}/?payment=cancelled&type=${planType}`;
      let stripe;
      try {
        stripe = getStripe();
      } catch (keyErr) {
        console.error("[ZUNEVIO AI Stripe] Clave STRIPE_SECRET_KEY no configurada:", keyErr?.message || keyErr);
        return res.status(503).json({
          error: "La pasarela Stripe no est\xE1 disponible en este momento. La variable STRIPE_SECRET_KEY debe estar configurada en el servidor."
        });
      }
      const existingBilling = userId ? getStripeBillingForUser(userId) : null;
      const existingCustomerId = existingBilling?.stripeCustomerId;
      console.info(`[ZUNEVIO AI Stripe] Creando Checkout Session para "${planType}" con priceId: ${productConfig.priceId}`);
      const sessionCreateParams = {
        payment_method_types: ["card"],
        line_items: [
          {
            price: productConfig.priceId,
            quantity: 1
          }
        ],
        mode: productConfig.mode,
        client_reference_id: userId || void 0,
        metadata: {
          userId: userId || "",
          planType,
          priceId: productConfig.priceId,
          productName: productConfig.name
        },
        success_url: finalSuccessUrl,
        cancel_url: finalCancelUrl
      };
      if (existingCustomerId) {
        sessionCreateParams.customer = existingCustomerId;
      } else if (userEmail) {
        sessionCreateParams.customer_email = userEmail;
      }
      if (productConfig.mode === "subscription") {
        sessionCreateParams.subscription_data = {
          metadata: {
            userId: userId || "",
            planType: "premium_subscription"
          }
        };
      }
      const session = await stripe.checkout.sessions.create(sessionCreateParams);
      if (!session.url) {
        return res.status(500).json({
          error: "Stripe no gener\xF3 una URL v\xE1lida para la sesi\xF3n de pago."
        });
      }
      return res.json({
        url: session.url,
        sessionId: session.id
      });
    } catch (stripeErr) {
      console.error("[ZUNEVIO AI Stripe Checkout Error]:", stripeErr?.message || stripeErr);
      return res.status(500).json({
        error: stripeErr?.message || "Error inesperado al conectar con Stripe Checkout."
      });
    }
  });
  app.post("/api/stripe/webhook", async (req, res) => {
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!webhookSecret) {
      console.error(
        "[ZUNEVIO AI Stripe Webhook] AVISO CR\xCDTICO: STRIPE_WEBHOOK_SECRET no est\xE1 configurado en las variables de entorno. Imposible verificar la firma criptogr\xE1fica del webhook de Stripe."
      );
      return res.status(503).json({
        error: "STRIPE_WEBHOOK_SECRET no est\xE1 configurado en las variables de entorno del servidor. Por favor, configura el secreto del endpoint de webhook (whsec_...) en los ajustes del proyecto."
      });
    }
    const sig = req.headers["stripe-signature"];
    if (!sig) {
      console.warn("[ZUNEVIO AI Stripe Webhook] Rechazado: Petici\xF3n sin cabecera stripe-signature.");
      return res.status(400).json({ error: "Cabecera stripe-signature requerida." });
    }
    const rawBody = req.rawBody || (Buffer.isBuffer(req.body) ? req.body : Buffer.from(typeof req.body === "string" ? req.body : JSON.stringify(req.body || {})));
    let event;
    try {
      const stripe = getStripe();
      event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret);
    } catch (err) {
      console.error("[ZUNEVIO AI Stripe Webhook] Error verificando firma del webhook:", err?.message || err);
      return res.status(400).send(`Webhook signature verification failed: ${err?.message}`);
    }
    console.info(`[ZUNEVIO AI Stripe Webhook] Evento verificado recibido: ${event.id} [${event.type}]`);
    const store = loadStripeStore();
    if (store.processedEvents[event.id]) {
      console.info(`[ZUNEVIO AI Stripe Webhook] Evento duplicado ignorado (idempotencia): ${event.id}`);
      return res.json({ received: true, duplicate: true });
    }
    try {
      switch (event.type) {
        case "checkout.session.completed": {
          const session = event.data.object;
          console.info(`[ZUNEVIO AI Stripe Webhook] checkout.session.completed: ${session.id}, status: ${session.payment_status}, mode: ${session.mode}`);
          const isPaid = session.payment_status === "paid" || session.mode === "subscription";
          if (!isPaid) {
            console.warn(`[ZUNEVIO AI Stripe Webhook] Checkout session ${session.id} omitida: no est\xE1 pagada (payment_status: ${session.payment_status})`);
            store.processedEvents[event.id] = {
              id: event.id,
              type: event.type,
              processedAt: (/* @__PURE__ */ new Date()).toISOString(),
              status: "skipped",
              summary: `Pago pendiente o no completado (${session.payment_status})`
            };
            saveStripeStore(store);
            return res.json({ received: true, status: "skipped_not_paid" });
          }
          const userId = session.client_reference_id || session.metadata?.userId || (typeof session.customer === "string" ? store.customerToUser[session.customer] : null);
          const planType = session.metadata?.planType;
          const priceId = session.metadata?.priceId;
          const userEmail = session.customer_details?.email || session.customer_email || void 0;
          const customerId = typeof session.customer === "string" ? session.customer : void 0;
          const subscriptionId = typeof session.subscription === "string" ? session.subscription : void 0;
          if (!userId) {
            console.warn(`[ZUNEVIO AI Stripe Webhook] No se encontr\xF3 userId para la sesi\xF3n ${session.id}. Email: ${userEmail || "N/A"}`);
            store.processedEvents[event.id] = {
              id: event.id,
              type: event.type,
              processedAt: (/* @__PURE__ */ new Date()).toISOString(),
              status: "skipped",
              summary: "Falta userId en metadata y client_reference_id"
            };
            saveStripeStore(store);
            return res.json({ received: true, status: "skipped_missing_userid" });
          }
          if (planType === "photos_pack") {
            await userCoordinator.runExclusive(userId, async () => {
              await applyPhotosPackFulfillment(
                userId,
                event.id,
                10,
                "Compra confirmada de Pack 10 Fotos con IA (Stripe Webhook)",
                userEmail,
                void 0
              );
            });
          } else if (planType === "credits_pack" || priceId === "price_1UH78I2QG2ejGGDv05ZSIn9U" || priceId === "price_1UH6MjEACZXC7XZq55nji8b4") {
            await userCoordinator.runExclusive(userId, async () => {
              await applyCreditsPackFulfillment(
                userId,
                event.id,
                200,
                "Compra confirmada de 200 cr\xE9ditos (Stripe Webhook)",
                userEmail
              );
            });
          } else if (planType === "premium_subscription" || priceId === "price_1UH7AO2QG2ejGGDvzTu3yQtP" || priceId === "price_1UH6QqEACZXC7XZqZtgwPUAs" || session.mode === "subscription") {
            await userCoordinator.runExclusive(userId, async () => {
              await applyPremiumSubscriptionActivation(
                userId,
                event.id,
                customerId,
                subscriptionId,
                userEmail
              );
            });
          }
          store.processedEvents[event.id] = {
            id: event.id,
            type: event.type,
            processedAt: (/* @__PURE__ */ new Date()).toISOString(),
            userId,
            planType: planType || (session.mode === "subscription" ? "premium_subscription" : "credits_pack"),
            status: "processed"
          };
          saveStripeStore(store);
          break;
        }
        case "customer.subscription.created": {
          const subscription = event.data.object;
          console.info(`[ZUNEVIO AI Stripe Webhook] customer.subscription.created: ${subscription.id}, status: ${subscription.status}`);
          const customerId = typeof subscription.customer === "string" ? subscription.customer : void 0;
          const subUserId = subscription.metadata?.userId || store.subscriptionToUser[subscription.id] || (customerId ? store.customerToUser[customerId] : null);
          if (subUserId && (subscription.status === "active" || subscription.status === "trialing")) {
            await userCoordinator.runExclusive(subUserId, async () => {
              await applyPremiumSubscriptionActivation(
                subUserId,
                event.id,
                customerId,
                subscription.id
              );
            });
          }
          store.processedEvents[event.id] = {
            id: event.id,
            type: event.type,
            processedAt: (/* @__PURE__ */ new Date()).toISOString(),
            userId: subUserId || void 0,
            status: "processed"
          };
          saveStripeStore(store);
          break;
        }
        case "customer.subscription.updated": {
          const subscription = event.data.object;
          console.info(`[ZUNEVIO AI Stripe Webhook] customer.subscription.updated: ${subscription.id}, status: ${subscription.status}`);
          const customerId = typeof subscription.customer === "string" ? subscription.customer : void 0;
          const subUserId = subscription.metadata?.userId || store.subscriptionToUser[subscription.id] || (customerId ? store.customerToUser[customerId] : null);
          if (subUserId) {
            if (subscription.status === "active" || subscription.status === "trialing") {
              await userCoordinator.runExclusive(subUserId, async () => {
                await applyPremiumSubscriptionActivation(
                  subUserId,
                  event.id,
                  customerId,
                  subscription.id
                );
              });
            } else if (["canceled", "unpaid", "incomplete_expired", "past_due"].includes(subscription.status)) {
              await userCoordinator.runExclusive(subUserId, async () => {
                await applyPremiumSubscriptionCancellation(
                  subUserId,
                  event.id,
                  `Estado de suscripci\xF3n actualizado a: ${subscription.status}`
                );
              });
            }
          }
          store.processedEvents[event.id] = {
            id: event.id,
            type: event.type,
            processedAt: (/* @__PURE__ */ new Date()).toISOString(),
            userId: subUserId || void 0,
            status: "processed"
          };
          saveStripeStore(store);
          break;
        }
        case "customer.subscription.deleted": {
          const subscription = event.data.object;
          console.info(`[ZUNEVIO AI Stripe Webhook] customer.subscription.deleted: ${subscription.id}`);
          const customerId = typeof subscription.customer === "string" ? subscription.customer : void 0;
          const subUserId = subscription.metadata?.userId || store.subscriptionToUser[subscription.id] || (customerId ? store.customerToUser[customerId] : null);
          if (subUserId) {
            await userCoordinator.runExclusive(subUserId, async () => {
              await applyPremiumSubscriptionCancellation(
                subUserId,
                event.id,
                "Suscripci\xF3n eliminada/cancelada en Stripe"
              );
            });
          }
          store.processedEvents[event.id] = {
            id: event.id,
            type: event.type,
            processedAt: (/* @__PURE__ */ new Date()).toISOString(),
            userId: subUserId || void 0,
            status: "processed"
          };
          saveStripeStore(store);
          break;
        }
        case "invoice.payment_succeeded": {
          const rawInvoice = event.data.object;
          const customerId = typeof rawInvoice.customer === "string" ? rawInvoice.customer : void 0;
          const subId = typeof rawInvoice.subscription === "string" ? rawInvoice.subscription : rawInvoice.subscription?.id || void 0;
          const invUserId = (subId ? store.subscriptionToUser[subId] : null) || (customerId ? store.customerToUser[customerId] : null);
          if (invUserId && subId) {
            await userCoordinator.runExclusive(invUserId, async () => {
              await applyPremiumSubscriptionActivation(
                invUserId,
                event.id,
                customerId,
                subId
              );
            });
          }
          store.processedEvents[event.id] = {
            id: event.id,
            type: event.type,
            processedAt: (/* @__PURE__ */ new Date()).toISOString(),
            userId: invUserId || void 0,
            status: "processed"
          };
          saveStripeStore(store);
          break;
        }
        default: {
          store.processedEvents[event.id] = {
            id: event.id,
            type: event.type,
            processedAt: (/* @__PURE__ */ new Date()).toISOString(),
            status: "processed"
          };
          saveStripeStore(store);
          break;
        }
      }
      return res.json({ received: true });
    } catch (procErr) {
      console.error(`[ZUNEVIO AI Stripe Webhook Error]:`, procErr?.message || procErr);
      return res.status(500).json({ error: "Error procesando el evento del webhook en el servidor." });
    }
  });
  app.post("/api/stripe/customer-portal", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      const userId = verified?.uid || (typeof req.body?.userId === "string" ? req.body.userId.trim() : void 0);
      if (!userId) {
        return res.status(401).json({ error: "No autenticado. Inicia sesi\xF3n con Google para acceder al portal de clientes." });
      }
      let stripe;
      try {
        stripe = getStripe();
      } catch (keyErr) {
        return res.status(503).json({ error: "Stripe no est\xE1 configurado en el servidor (falta STRIPE_SECRET_KEY)." });
      }
      const store = loadStripeStore();
      let customerId = store.userBillings[userId]?.stripeCustomerId || (typeof req.body?.customerId === "string" ? req.body.customerId : void 0);
      if (!customerId && (verified?.email || req.body?.email)) {
        const emailToSearch = verified?.email || req.body?.email;
        try {
          const customers = await stripe.customers.list({ email: emailToSearch, limit: 1 });
          if (customers.data.length > 0) {
            customerId = customers.data[0].id;
            const existing = store.userBillings[userId] || {
              userId,
              email: emailToSearch,
              plan: "free",
              purchasedCreditsBalance: 0,
              lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
              history: []
            };
            existing.stripeCustomerId = customerId;
            store.userBillings[userId] = existing;
            store.customerToUser[customerId] = userId;
            saveStripeStore(store);
          }
        } catch (searchErr) {
          console.warn("[ZUNEVIO AI Stripe Portal] Error buscando cliente por email en Stripe:", searchErr);
        }
      }
      if (!customerId) {
        return res.status(404).json({
          error: "No se encontr\xF3 un registro de cliente de Stripe para tu cuenta. Si a\xFAn no te has suscrito al Plan Premium, puedes hacerlo desde la secci\xF3n de Planes."
        });
      }
      const rawOrigin = req.headers.origin || (req.headers.referer ? new URL(req.headers.referer).origin : "");
      const defaultOrigin = process.env.APP_URL || rawOrigin || "http://localhost:3000";
      const cleanOrigin = defaultOrigin.replace(/\/+$/, "");
      const returnUrl = typeof req.body?.returnUrl === "string" && req.body.returnUrl.startsWith("http") ? req.body.returnUrl : `${cleanOrigin}/`;
      const portalSession = await stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: returnUrl
      });
      return res.json({
        url: portalSession.url
      });
    } catch (portalErr) {
      console.error("[ZUNEVIO AI Stripe Customer Portal Error]:", portalErr?.message || portalErr);
      return res.status(500).json({
        error: portalErr?.message || "Error al conectar con el portal de facturaci\xF3n de Stripe."
      });
    }
  });
  app.post("/api/stripe/confirm-session", async (req, res) => {
    try {
      const { sessionId } = req.body || {};
      if (!sessionId || typeof sessionId !== "string") {
        return res.status(400).json({ error: "sessionId requerido." });
      }
      const verified = await authenticateRequest(req);
      const userId = verified?.uid || (typeof req.body?.userId === "string" ? req.body.userId.trim() : void 0);
      if (!userId) {
        return res.status(401).json({ error: "Usuario no autenticado." });
      }
      let stripe;
      try {
        stripe = getStripe();
      } catch (keyErr) {
        return res.status(503).json({ error: "Stripe no configurado." });
      }
      const session = await stripe.checkout.sessions.retrieve(sessionId, {
        expand: ["customer", "subscription"]
      });
      if (session.payment_status !== "paid" && session.mode !== "subscription") {
        return res.status(400).json({
          success: false,
          error: `La sesi\xF3n de pago no est\xE1 confirmada (estado: ${session.payment_status}).`
        });
      }
      const sessionUser = session.client_reference_id || session.metadata?.userId;
      if (sessionUser && sessionUser !== userId) {
        return res.status(403).json({ error: "Esta sesi\xF3n de pago no pertenece a tu usuario." });
      }
      const syntheticEventId = `checkout_confirm_${session.id}`;
      const planType = session.metadata?.planType;
      const priceId = session.metadata?.priceId;
      const customerId = typeof session.customer === "string" ? session.customer : session.customer?.id;
      const subscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id;
      const userEmail = session.customer_details?.email || session.customer_email || verified?.email;
      let resultPlan = "free";
      let resultCredits = 0;
      await userCoordinator.runExclusive(userId, async () => {
        const store = loadStripeStore();
        if (planType === "photos_pack") {
          if (!store.processedEvents[syntheticEventId]) {
            await applyPhotosPackFulfillment(
              userId,
              syntheticEventId,
              10,
              "Compra confirmada de Pack 10 Fotos con IA (Confirm Session Directa)",
              userEmail,
              verified?.idToken
            );
            store.processedEvents[syntheticEventId] = {
              id: syntheticEventId,
              type: "checkout.session.completed",
              processedAt: (/* @__PURE__ */ new Date()).toISOString(),
              userId,
              planType: "photos_pack",
              status: "processed"
            };
            saveStripeStore(store);
          }
          resultPlan = store.userBillings[userId]?.plan || "free";
          resultCredits = store.userBillings[userId]?.purchasedCreditsBalance || 0;
        } else if (planType === "credits_pack" || priceId === "price_1UH78I2QG2ejGGDv05ZSIn9U" || priceId === "price_1UH6MjEACZXC7XZq55nji8b4") {
          if (!store.processedEvents[syntheticEventId]) {
            const resData = await applyCreditsPackFulfillment(
              userId,
              syntheticEventId,
              200,
              "Compra confirmada de 200 cr\xE9ditos (Confirm Session Directa)",
              userEmail,
              verified?.idToken
            );
            resultCredits = resData.newBalance;
            store.processedEvents[syntheticEventId] = {
              id: syntheticEventId,
              type: "checkout.session.completed",
              processedAt: (/* @__PURE__ */ new Date()).toISOString(),
              userId,
              planType: "credits_pack",
              status: "processed"
            };
            saveStripeStore(store);
          } else {
            resultCredits = store.userBillings[userId]?.purchasedCreditsBalance || 0;
          }
          resultPlan = store.userBillings[userId]?.plan || "free";
        } else if (planType === "premium_subscription" || priceId === "price_1UH7AO2QG2ejGGDvzTu3yQtP" || priceId === "price_1UH6QqEACZXC7XZqZtgwPUAs" || session.mode === "subscription") {
          if (!store.processedEvents[syntheticEventId]) {
            await applyPremiumSubscriptionActivation(
              userId,
              syntheticEventId,
              customerId,
              subscriptionId,
              userEmail,
              verified?.idToken
            );
            store.processedEvents[syntheticEventId] = {
              id: syntheticEventId,
              type: "checkout.session.completed",
              processedAt: (/* @__PURE__ */ new Date()).toISOString(),
              userId,
              planType: "premium_subscription",
              status: "processed"
            };
            saveStripeStore(store);
          }
          resultPlan = "premium";
          resultCredits = store.userBillings[userId]?.purchasedCreditsBalance || 0;
        }
      });
      return res.json({
        success: true,
        plan: resultPlan,
        purchasedCreditsBalance: resultCredits,
        message: "Pago verificado y activado con \xE9xito."
      });
    } catch (confirmErr) {
      console.error("[ZUNEVIO AI Stripe Confirm Session Error]:", confirmErr?.message || confirmErr);
      return res.status(500).json({ error: confirmErr?.message || "Error al verificar la sesi\xF3n de Stripe." });
    }
  });
  app.get("/api/stripe/user-status", async (req, res) => {
    try {
      const verified = await authenticateRequest(req);
      if (!verified?.uid) {
        return res.status(401).json({ error: "No autenticado." });
      }
      const billing = getStripeBillingForUser(verified.uid);
      return res.json({
        plan: billing?.plan || "free",
        purchasedCreditsBalance: billing?.purchasedCreditsBalance || 0,
        stripeCustomerId: billing?.stripeCustomerId || null,
        hasActiveSubscription: billing?.plan === "premium" && billing?.subscriptionStatus === "active"
      });
    } catch (err) {
      return res.status(500).json({ error: err?.message || "Error al consultar estado de facturaci\xF3n." });
    }
  });
  const DELETION_STORE_FILE = import_path.default.join(process.cwd(), ".data", "deletion_requests.json");
  function saveDeletionRequestRecord(record) {
    try {
      const dataDir = import_path.default.join(process.cwd(), ".data");
      if (!import_node_fs.default.existsSync(dataDir)) {
        import_node_fs.default.mkdirSync(dataDir, { recursive: true });
      }
      let existing = [];
      if (import_node_fs.default.existsSync(DELETION_STORE_FILE)) {
        try {
          existing = JSON.parse(import_node_fs.default.readFileSync(DELETION_STORE_FILE, "utf8"));
        } catch {
          existing = [];
        }
      }
      existing.push(record);
      import_node_fs.default.writeFileSync(DELETION_STORE_FILE, JSON.stringify(existing, null, 2), "utf8");
    } catch (e) {
      console.error("[ZUNEVIO AI] Error persisting deletion request:", e);
    }
  }
  app.post("/api/request-deletion", async (req, res) => {
    try {
      const { email, reason, notes, confirmationCheck } = req.body || {};
      if (!email || typeof email !== "string" || !email.includes("@") || !email.includes(".")) {
        return res.status(400).json({ error: "Por favor, introduce una direcci\xF3n de correo electr\xF3nico v\xE1lida." });
      }
      if (!confirmationCheck) {
        return res.status(400).json({ error: "Debes confirmar expresamente que comprendes que la eliminaci\xF3n es definitiva." });
      }
      const clientIp = req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.socket.remoteAddress || "unknown";
      const cleanEmail = email.trim().toLowerCase();
      const ticketId = `DEL-${Date.now().toString(36).toUpperCase()}-${import_node_crypto.default.randomBytes(3).toString("hex").toUpperCase()}`;
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const record = {
        ticketId,
        email: cleanEmail,
        reason: typeof reason === "string" && reason ? reason.trim().slice(0, 200) : "Sin motivo especificado",
        notes: typeof notes === "string" && notes ? notes.trim().slice(0, 1e3) : "",
        requestedAt: nowIso,
        ip: clientIp,
        status: "pending"
      };
      saveDeletionRequestRecord(record);
      console.log(`[ZUNEVIO AI] Solicitud de eliminaci\xF3n externa registrada: ${ticketId} para cuenta ${cleanEmail}`);
      return res.json({
        success: true,
        ticketId,
        message: "Solicitud de baja y eliminaci\xF3n de datos registrada correctamente.",
        email: cleanEmail,
        timestamp: nowIso,
        estimatedResolution: "M\xE1ximo 72 horas h\xE1biles",
        contactEmail: "zunevio.app@protonmail.com"
      });
    } catch (err) {
      console.error("[ZUNEVIO AI] Error procesando solicitud de eliminaci\xF3n externa:", err);
      return res.status(500).json({ error: "Error interno al procesar la solicitud. Por favor, escribe a zunevio.app@protonmail.com." });
    }
  });
  app.get(["/delete-account", "/delete-account.html", "/solicitud-baja", "/solicitud-baja.html"], (_req, res) => {
    const distPath = import_path.default.join(process.cwd(), "dist", "delete-account.html");
    const publicPath = import_path.default.join(process.cwd(), "public", "delete-account.html");
    const targetPath = import_node_fs.default.existsSync(distPath) ? distPath : publicPath;
    if (import_node_fs.default.existsSync(targetPath)) {
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      return res.sendFile(targetPath);
    }
    return res.status(404).send("P\xE1gina de solicitud de eliminaci\xF3n no encontrada.");
  });
  app.get("/sitemap.xml", (_req, res) => {
    const distSitemapPath = import_path.default.join(process.cwd(), "dist", "sitemap.xml");
    const publicSitemapPath = import_path.default.join(process.cwd(), "public", "sitemap.xml");
    const targetPath = import_node_fs.default.existsSync(distSitemapPath) ? distSitemapPath : publicSitemapPath;
    if (import_node_fs.default.existsSync(targetPath)) {
      res.setHeader("Content-Type", "application/xml; charset=utf-8");
      return res.sendFile(targetPath);
    }
    return res.status(404).send("Sitemap not found");
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, HOST, () => {
    console.log(`[ZUNEVIO AI] Server running on http://${HOST}:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("[ZUNEVIO AI Fatal Error]:", err);
});
//# sourceMappingURL=server.cjs.map

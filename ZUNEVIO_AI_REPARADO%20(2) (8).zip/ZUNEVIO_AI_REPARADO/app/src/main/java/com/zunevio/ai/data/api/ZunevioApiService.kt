package com.zunevio.ai.data.api

import com.google.firebase.auth.FirebaseAuth
import com.zunevio.ai.data.model.ChatApiRequest
import com.zunevio.ai.data.model.ChatApiResponse
import com.zunevio.ai.data.model.StripeCheckoutRequest
import com.zunevio.ai.data.model.StripeCheckoutResponse
import kotlinx.coroutines.tasks.await
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface ZunevioApiService {
    @POST("api/chat")
    suspend fun sendChat(@Body request: ChatApiRequest): ChatApiResponse

    @POST("api/stripe/create-checkout-session")
    suspend fun createCheckoutSession(@Body request: StripeCheckoutRequest): StripeCheckoutResponse
}

/**
 * Interceptor para adjuntar automáticamente el ID Token de Firebase Authentication
 * garantizando la misma seguridad que la versión web.
 */
class FirebaseAuthInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val user = FirebaseAuth.getInstance().currentUser
        val builder = original.newBuilder()

        // Si el usuario tiene sesión activa, adjunta el token en la cabecera Bearer
        if (user != null) {
            try {
                // Obtenemos el token de forma síncrona dentro del hilo de red de OkHttp
                val task = user.getIdToken(false)
                val tokenResult = com.google.android.gms.tasks.Tasks.await(task, 5, TimeUnit.SECONDS)
                val token = tokenResult.token
                if (!token.isNullOrEmpty()) {
                    builder.header("Authorization", "Bearer $token")
                }
            } catch (e: Exception) {
                // Continúa como invitado si falla la obtención del token
            }
        }

        builder.header("Accept", "application/json")
        builder.header("Content-Type", "application/json")
        return chain.proceed(builder.build())
    }
}

object ApiClient {
    // URL base de producción de ZUNEVIO AI
    private const val BASE_URL = "https://zunevio-ai.ai.studio/"

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(FirebaseAuthInterceptor())
        .addInterceptor(logging)
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val apiService: ZunevioApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ZunevioApiService::class.java)
    }
}

package com.zunevio.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zunevio.ai.data.model.AgendaEvent
import com.zunevio.ai.data.repository.ZunevioRepository
import com.zunevio.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AgendaScreen(
    repository: ZunevioRepository,
    uid: String
) {
    val coroutineScope = rememberCoroutineScope()
    val events by repository.getAgendaFlow(uid).collectAsState(initial = emptyList())
    var showDialog by remember { mutableStateOf(false) }
    var eventTitle by remember { mutableStateOf("") }
    var eventDate by remember { mutableStateOf("") }
    var eventNotes by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = ZunevioCyan, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("Agenda de Citas y Tareas", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Organización inteligente sincronizada.", color = TextSlate400, fontSize = 12.sp)
                }
            }

            IconButton(
                onClick = { showDialog = true },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(ZunevioBlue)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Nuevo Evento", tint = TextWhite)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (events.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No hay eventos programados.\nPuedes registrar citas aquí o pedirle a ZUNEVIO AI que las guarde.",
                    color = TextSlate400,
                    fontSize = 13.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(events) { ev ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ev.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                if (ev.dateTime.isNotEmpty()) {
                                    Text("🕒 ${ev.dateTime}", color = ZunevioCyan, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                                }
                                if (ev.notes.isNotEmpty()) {
                                    Text(ev.notes, color = TextSlate400, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                                }
                            }
                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        repository.deleteAgendaEvent(uid, ev.id)
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = RedDanger.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            containerColor = CardBackground,
            title = { Text("Nuevo Evento", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextField(
                        value = eventTitle,
                        onValueChange = { eventTitle = it },
                        placeholder = { Text("Título de la reunión o cita...", color = TextSlate500) },
                        colors = TextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite)
                    )
                    TextField(
                        value = eventDate,
                        onValueChange = { eventDate = it },
                        placeholder = { Text("Fecha u hora (ej: Mañana a las 10:00)", color = TextSlate500) },
                        colors = TextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite)
                    )
                    TextField(
                        value = eventNotes,
                        onValueChange = { eventNotes = it },
                        placeholder = { Text("Notas adicionales (opcional)", color = TextSlate500) },
                        colors = TextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (eventTitle.isNotBlank()) {
                            val title = eventTitle.trim()
                            val date = eventDate.trim()
                            val notes = eventNotes.trim()
                            showDialog = false
                            eventTitle = ""
                            eventDate = ""
                            eventNotes = ""
                            coroutineScope.launch {
                                repository.addAgendaEvent(uid, title, date, notes)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZunevioBlue)
                ) {
                    Text("Guardar", color = TextWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancelar", color = TextSlate400)
                }
            }
        )
    }
}

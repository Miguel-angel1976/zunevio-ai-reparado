package com.zunevio.ai.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zunevio.ai.data.model.UserProfile
import com.zunevio.ai.data.repository.ZunevioRepository
import com.zunevio.ai.ui.components.GoldenCrowns
import com.zunevio.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun PlanesScreen(
    repository: ZunevioRepository,
    userProfile: UserProfile?
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isProcessingStripe by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val handleStripeCheckout: (String, Boolean) -> Unit = { priceId, isSubscription ->
        coroutineScope.launch {
            try {
                isProcessingStripe = true
                errorMessage = null
                val response = repository.createStripeCheckout(priceId, isSubscription)
                if (response.url.isNotEmpty()) {
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(response.url))
                    context.startActivity(browserIntent)
                }
            } catch (e: Exception) {
                errorMessage = "No se pudo iniciar el proceso de pago seguro: ${e.localizedMessage}"
            } finally {
                isProcessingStripe = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        ) {
            Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = CrownGoldMain, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text("Planes y Capacidad", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Elige el plan ideal para tus tareas y consultas.", color = TextSlate400, fontSize = 12.sp)
            }
        }

        if (errorMessage != null) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = RedDanger.copy(alpha = 0.2f))
            ) {
                Text(errorMessage ?: "", color = TextWhite, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // PLAN 1: ESTÁNDAR (GRATUITO)
        Card(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Plan Estándar", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(ZunevioBlue.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Gratuito", color = ZunevioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text("0 € / mes", color = TextWhite, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 8.dp))
                Text("Ideal para uso diario, consultas rápidas y tareas cotidianas.", color = TextSlate300, fontSize = 13.sp)

                Spacer(modifier = Modifier.height(12.dp))
                listOf(
                    "20 créditos diarios que se renuevan cada 24 horas",
                    "Modelo oficial Gemini 3.8 Flash",
                    "Búsqueda web con Google Grounding",
                    "Memoria privada y Cesta del súper sincronizadas"
                ).forEach { feat ->
                    Row(modifier = Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = ZunevioCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(feat, color = TextSlate200, fontSize = 12.sp)
                    }
                }
            }
        }

        // PLAN 2: PREMIUM CON CORONAS DORADAS
        Card(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF081432)),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Brush.linearGradient(listOf(CrownGoldMain, ZunevioBlue)))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GoldenCrowns()
                Spacer(modifier = Modifier.height(8.dp))
                Text("Plan Premium", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("9,99 € / mes", color = CrownGoldLight, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 6.dp))
                Text("Máxima velocidad, 500 consultas prioritarias y acceso sin restricciones.", color = TextSlate300, fontSize = 13.sp)

                Spacer(modifier = Modifier.height(12.dp))
                Column(modifier = Modifier.fillMaxWidth()) {
                    listOf(
                        "500 créditos diarios de máxima prioridad",
                        "Respuestas instantáneas sin tiempos de espera",
                        "Generación ampliada en el Estudio de Fotos",
                        "Carga simultánea de múltiples documentos pesados",
                        "Soporte técnico preferente"
                    ).forEach { feat ->
                        Row(modifier = Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = CrownGoldMain, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(feat, color = TextSlate200, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { handleStripeCheckout("price_premium_monthly", true) },
                    enabled = !isProcessingStripe,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ZunevioBlue)
                ) {
                    if (isProcessingStripe) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TextWhite)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Suscribirse con Stripe (9,99 €/mes)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // PACK DE CRÉDITOS QUE NO CADUCAN
        Card(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("Pack Extra de 200 Créditos", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("4,99 € (pago único) • Los créditos nunca caducan", color = ZunevioCyan, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))
                Text("Ideal para proyectos puntuales o uso intensivo de documentos.", color = TextSlate400, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { handleStripeCheckout("price_credits_pack_200", false) },
                    enabled = !isProcessingStripe,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Comprar Pack de 200 Créditos", color = TextWhite)
                }
            }
        }
    }
}

package com.zunevio.ai.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zunevio.ai.data.model.UserProfile
import com.zunevio.ai.ui.theme.*

@Composable
fun ReferidosScreen(
    userProfile: UserProfile?
) {
    val context = LocalContext.current
    val refCode = userProfile?.referralCode ?: "ZUNEVIO"
    val shareLink = "https://zunevio-ai.ai.studio/?ref=$refCode"
    val validReferrals = userProfile?.validReferrals ?: 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Share, contentDescription = null, tint = ZunevioCyan, modifier = Modifier.size(36.dp))
        Spacer(modifier = Modifier.height(8.dp))
        Text("Comparte ZUNEVIO AI y gana créditos", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(
            "Invita a tus compañeros y recibe 20 créditos permanentes por cada nuevo usuario registrado.",
            color = TextSlate300,
            fontSize = 13.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        // Tarjeta con Código y Enlace
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Tu código de invitación único:", color = TextSlate400, fontSize = 12.sp)
                Text(refCode, color = ZunevioCyan, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 8.dp))

                // Indicador de progreso 0/2
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 12.dp)
                ) {
                    repeat(2) { index ->
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(if (index < validReferrals) ZunevioCyan else CardBorder)
                        )
                    }
                    Text("$validReferrals/2 amigos registrados", color = TextSlate300, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Copiar enlace
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Zunevio Link", shareLink))
                            Toast.makeText(context, "¡Enlace copiado al portapapeles!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copiar Enlace", fontSize = 12.sp)
                    }

                    // Compartir vía Sharesheet de Android (WhatsApp, Telegram, etc.)
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Descubre ZUNEVIO AI")
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "¡Prueba ZUNEVIO AI! Asistente de inteligencia artificial gratis con 20 créditos diarios: $shareLink"
                                )
                            }
                            context.startActivity(Intent.createChooser(intent, "Compartir ZUNEVIO AI"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ZunevioBlue),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Compartir", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

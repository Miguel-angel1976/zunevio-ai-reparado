package com.zunevio.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta de colores oficial de ZUNEVIO AI (Deep Space Blue & Neon Cyberpunk)
val SpaceBlack = Color(0xFF020511)
val SpaceDeepBlue = Color(0xFF040816)
val CardBackground = Color(0xFF060E28)
val CardBorder = Color(0x330088FF)
val CardBorderHover = Color(0x6600E5FF)

val ZunevioBlue = Color(0xFF0066FF)
val ZunevioCyan = Color(0xFF00F0FF)
val ZunevioLightCyan = Color(0xFF67E8F9)
val ZunevioElectricBlue = Color(0xFF00A3FF)

val CrownGoldLight = Color(0xFFFFDE6A)
val CrownGoldMain = Color(0xFFF5B300)
val CrownGoldDark = Color(0xFFC98600)

val TextWhite = Color(0xFFFFFFFF)
val TextSlate200 = Color(0xFFE2E8F0)
val TextSlate300 = Color(0xFFCBD5E1)
val TextSlate400 = Color(0xFF94A3B8)
val TextSlate500 = Color(0xFF64748B)

val GreenSuccess = Color(0xFF10B981)
val RedDanger = Color(0xFFEF4444)

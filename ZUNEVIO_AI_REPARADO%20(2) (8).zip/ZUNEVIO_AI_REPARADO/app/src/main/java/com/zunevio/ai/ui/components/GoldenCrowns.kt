package com.zunevio.ai.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import com.zunevio.ai.ui.theme.CrownGoldDark
import com.zunevio.ai.ui.theme.CrownGoldLight
import com.zunevio.ai.ui.theme.CrownGoldMain

/**
 * Dos Coronas Doradas 3D distintivas de ZUNEVIO AI
 */
@Composable
fun GoldenCrowns(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.width(100.dp).height(40.dp)) {
        val width = size.width
        val height = size.height

        val goldBrush = Brush.linearGradient(
            colors = listOf(CrownGoldLight, CrownGoldMain, CrownGoldDark),
            start = Offset(0f, 0f),
            end = Offset(width, height)
        )

        // Corona Izquierda
        val path1 = Path().apply {
            moveTo(width * 0.1f, height * 0.7f)
            lineTo(width * 0.15f, height * 0.35f)
            lineTo(width * 0.25f, height * 0.55f)
            lineTo(width * 0.35f, height * 0.2f)
            lineTo(width * 0.45f, height * 0.55f)
            lineTo(width * 0.55f, height * 0.35f)
            lineTo(width * 0.6f, height * 0.7f)
            close()
        }
        drawPath(path1, goldBrush)

        // Corona Derecha (ligeramente inclinada y superpuesta)
        val path2 = Path().apply {
            moveTo(width * 0.4f, height * 0.75f)
            lineTo(width * 0.45f, height * 0.4f)
            lineTo(width * 0.55f, height * 0.6f)
            lineTo(width * 0.65f, height * 0.25f)
            lineTo(width * 0.75f, height * 0.6f)
            lineTo(width * 0.85f, height * 0.4f)
            lineTo(width * 0.9f, height * 0.75f)
            close()
        }
        drawPath(path2, goldBrush)
    }
}

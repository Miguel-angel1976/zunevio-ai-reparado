package com.zunevio.ai.data.repository

import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.zunevio.ai.data.api.ApiClient
import com.zunevio.ai.data.model.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ZunevioRepository(
    private val auth: FirebaseAuth = try {
        FirebaseAuth.getInstance()
    } catch (e: Exception) {
        FirebaseAuth.getInstance()
    },
    private val firestore: FirebaseFirestore = try {
        val app = FirebaseApp.getInstance()
        try {
            // Conecta a la base de datos Firestore configurada para ZUNEVIO AI
            FirebaseFirestore.getInstance(app, "ai-studio-zunevioai-182aba20-f8d9-4947-9a4a-855259ee53b9")
        } catch (e: Exception) {
            FirebaseFirestore.getInstance(app)
        }
    } catch (e: Exception) {
        FirebaseFirestore.getInstance()
    }
) {

    val currentUser: FirebaseUser?
        get() = try { auth.currentUser } catch (e: Exception) { null }

    /**
     * Inicio de sesión anónimo (Modo Invitado idéntico a la web) con tolerancia a fallos.
     * Si la corrutina es cancelada por Compose, reemite CancellationException respetando la concurrencia estructurada.
     */
    suspend fun signInAnonymously(): FirebaseUser? {
        return try {
            val result = auth.signInAnonymously().await()
            result.user?.let {
                try {
                    ensureUserProfileExists(it)
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                    android.util.Log.w("ZUNEVIO_AI", "Aviso no crítico asegurando perfil en Firestore: ${e.message}")
                }
            }
            result.user
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            android.util.Log.e("ZUNEVIO_AI", "Aviso en login anónimo de Firebase: ${e.message}")
            try { auth.currentUser } catch (err: Exception) { null }
        }
    }

    /**
     * Asegura que el documento de usuario en Firestore existe con sus 20 créditos iniciales.
     * Nunca permite que un UID vacío intente consultar o crear un documento.
     */
    private suspend fun ensureUserProfileExists(user: FirebaseUser) {
        val uid = user.uid
        if (uid.isBlank()) return
        try {
            val userRef = firestore.collection("users").document(uid)
            val snapshot = userRef.get().await()
            if (!snapshot.exists()) {
                val initialProfile = hashMapOf(
                    "uid" to uid,
                    "email" to (user.email ?: ""),
                    "displayName" to (user.displayName ?: "Usuario Invitado"),
                    "plan" to "standard",
                    "credits" to 20,
                    "dailyCreditsQuota" to 20,
                    "validReferrals" to 0,
                    "referralCode" to uid.take(8).uppercase(),
                    "isAnonymous" to user.isAnonymous,
                    "createdAt" to Timestamp.now()
                )
                userRef.set(initialProfile).await()
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            android.util.Log.w("ZUNEVIO_AI", "Aviso asegurando perfil en Firestore: ${e.message}")
        }
    }

    /**
     * Flujo en tiempo real del perfil del usuario (créditos, plan, referidos).
     * Solo emite datos auténticos confirmados desde Firestore.
     * Si el UID está vacío, no ejecuta ninguna consulta a Firestore.
     */
    fun getUserProfileFlow(uid: String): Flow<UserProfile?> = callbackFlow {
        if (uid.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }
        val listener = try {
            firestore.collection("users").document(uid)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        trySend(null)
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        try {
                            val profile = UserProfile(
                                uid = uid,
                                email = snapshot.getString("email") ?: "",
                                displayName = snapshot.getString("displayName") ?: "Usuario",
                                photoUrl = snapshot.getString("photoUrl") ?: "",
                                plan = snapshot.getString("plan") ?: "standard",
                                credits = snapshot.getLong("credits")?.toInt() ?: 0,
                                dailyCreditsQuota = snapshot.getLong("dailyCreditsQuota")?.toInt() ?: 0,
                                validReferrals = snapshot.getLong("validReferrals")?.toInt() ?: 0,
                                referralCode = snapshot.getString("referralCode") ?: "",
                                isAnonymous = snapshot.getBoolean("isAnonymous") ?: false
                            )
                            trySend(profile)
                        } catch (e: Exception) {
                            trySend(null)
                        }
                    } else {
                        trySend(null)
                    }
                }
        } catch (e: Exception) {
            trySend(null)
            null
        }
        awaitClose { listener?.remove() }
    }

    /**
     * Envío de mensaje a Gemini a través del backend oficial de ZUNEVIO AI.
     */
    suspend fun sendChatMessage(
        message: String,
        history: List<ChatHistoryItem>,
        searchWeb: Boolean,
        autoMemory: Boolean
    ): ChatApiResponse {
        val request = ChatApiRequest(
            message = message,
            history = history,
            searchWeb = searchWeb,
            autoMemory = autoMemory
        )
        return ApiClient.apiService.sendChat(request)
    }

    // --- CESTA DEL SÚPER ---
    fun getCestaFlow(uid: String): Flow<List<CestaItem>> = callbackFlow {
        if (uid.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val listener = try {
            firestore.collection("users").document(uid).collection("cesta")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        trySend(emptyList())
                        return@addSnapshotListener
                    }
                    val items = snapshot?.documents?.mapNotNull { doc ->
                        CestaItem(
                            id = doc.id,
                            name = doc.getString("name") ?: "",
                            completed = doc.getBoolean("completed") ?: false,
                            createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                        )
                    } ?: emptyList()
                    trySend(items)
                }
        } catch (e: Exception) {
            trySend(emptyList())
            null
        }
        awaitClose { listener?.remove() }
    }

    suspend fun addCestaItem(uid: String, name: String) {
        if (uid.isBlank() || name.isBlank()) return
        try {
            val item = hashMapOf(
                "name" to name.trim(),
                "completed" to false,
                "createdAt" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).collection("cesta").add(item).await()
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            android.util.Log.w("ZUNEVIO_AI", "Error añadiendo artículo a la cesta: ${e.message}")
        }
    }

    suspend fun toggleCestaItem(uid: String, itemId: String, currentStatus: Boolean) {
        if (uid.isBlank() || itemId.isBlank()) return
        try {
            firestore.collection("users").document(uid).collection("cesta").document(itemId)
                .update("completed", !currentStatus).await()
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            android.util.Log.w("ZUNEVIO_AI", "Error actualizando artículo de la cesta: ${e.message}")
        }
    }

    suspend fun deleteCestaItem(uid: String, itemId: String) {
        if (uid.isBlank() || itemId.isBlank()) return
        try {
            firestore.collection("users").document(uid).collection("cesta").document(itemId).delete().await()
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            android.util.Log.w("ZUNEVIO_AI", "Error eliminando artículo de la cesta: ${e.message}")
        }
    }

    // --- AGENDA DE EVENTOS ---
    fun getAgendaFlow(uid: String): Flow<List<AgendaEvent>> = callbackFlow {
        if (uid.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val listener = try {
            firestore.collection("users").document(uid).collection("agenda")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        trySend(emptyList())
                        return@addSnapshotListener
                    }
                    val events = snapshot?.documents?.mapNotNull { doc ->
                        AgendaEvent(
                            id = doc.id,
                            title = doc.getString("title") ?: "",
                            dateTime = doc.getString("dateTime") ?: "",
                            notes = doc.getString("notes") ?: "",
                            createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                        )
                    } ?: emptyList()
                    trySend(events)
                }
        } catch (e: Exception) {
            trySend(emptyList())
            null
        }
        awaitClose { listener?.remove() }
    }

    suspend fun addAgendaEvent(uid: String, title: String, dateTime: String, notes: String) {
        if (uid.isBlank() || title.isBlank()) return
        try {
            val event = hashMapOf(
                "title" to title.trim(),
                "dateTime" to dateTime.trim(),
                "notes" to notes.trim(),
                "createdAt" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).collection("agenda").add(event).await()
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            android.util.Log.w("ZUNEVIO_AI", "Error añadiendo evento a la agenda: ${e.message}")
        }
    }

    suspend fun deleteAgendaEvent(uid: String, eventId: String) {
        if (uid.isBlank() || eventId.isBlank()) return
        try {
            firestore.collection("users").document(uid).collection("agenda").document(eventId).delete().await()
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            android.util.Log.w("ZUNEVIO_AI", "Error eliminando evento de la agenda: ${e.message}")
        }
    }

    // --- MEMORIA PRIVADA ---
    fun getMemoriesFlow(uid: String): Flow<List<MemoryItem>> = callbackFlow {
        if (uid.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val listener = try {
            firestore.collection("users").document(uid).collection("memories")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        trySend(emptyList())
                        return@addSnapshotListener
                    }
                    val memories = snapshot?.documents?.mapNotNull { doc ->
                        MemoryItem(
                            id = doc.id,
                            text = doc.getString("text") ?: "",
                            category = doc.getString("category") ?: "general",
                            createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                        )
                    } ?: emptyList()
                    trySend(memories)
                }
        } catch (e: Exception) {
            trySend(emptyList())
            null
        }
        awaitClose { listener?.remove() }
    }

    suspend fun deleteMemory(uid: String, memoryId: String) {
        if (uid.isBlank() || memoryId.isBlank()) return
        try {
            firestore.collection("users").document(uid).collection("memories").document(memoryId).delete().await()
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            android.util.Log.w("ZUNEVIO_AI", "Error eliminando memoria: ${e.message}")
        }
    }

    // --- STRIPE CHECKOUT ---
    suspend fun createStripeCheckout(priceId: String, isSubscription: Boolean): StripeCheckoutResponse {
        val mode = if (isSubscription) "subscription" else "payment"
        return ApiClient.apiService.createCheckoutSession(StripeCheckoutRequest(priceId, mode))
    }
}

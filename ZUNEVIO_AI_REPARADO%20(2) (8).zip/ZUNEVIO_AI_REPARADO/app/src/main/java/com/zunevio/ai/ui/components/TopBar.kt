package com.zunevio.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zunevio.ai.data.model.UserProfile
import com.zunevio.ai.ui.theme.*

@Composable
fun TopBar(
    userProfile: UserProfile?,
    onOpenCesta: () -> Unit,
    onOpenAgenda: () -> Unit,
    onOpenPlanes: () -> Unit,
    onOpenProfile: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SpaceBlack)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Logo ZUNEVIO AI
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { onOpenProfile() }
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(listOf(ZunevioBlue, ZunevioCyan))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Z",
                    color = TextWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "ZUNEVIO AI",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "Tu asistente",
                    color = TextSlate400,
                    fontSize = 11.sp
                )
            }
        }

        // Acciones derecha: Créditos, Cesta, Agenda, Perfil
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Píldora de Créditos: Solo muestra créditos cuando están confirmados por el servidor
            val isConfirmed = userProfile != null
            val creditsText = if (isConfirmed) "${userProfile!!.credits} cr" else "Sincronizando..."
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(CardBackground)
                    .border(1.dp, ZunevioBlue.copy(alpha = 0.5f), RoundedCornerShape(50))
                    .clickable { onOpenPlanes() }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "Planes",
                        tint = if (userProfile?.plan == "premium") CrownGoldMain else ZunevioCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = creditsText,
                        color = TextWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Botón Cesta
            IconButton(
                onClick = onOpenCesta,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CardBackground)
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingBag,
                    contentDescription = "Cesta",
                    tint = ZunevioLightCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Botón Agenda
            IconButton(
                onClick = onOpenAgenda,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CardBackground)
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = "Agenda",
                    tint = ZunevioLightCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Avatar / Perfil
            IconButton(
                onClick = onOpenProfile,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CardBackground)
                    .border(1.dp, CardBorder, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Perfil",
                    tint = TextWhite,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

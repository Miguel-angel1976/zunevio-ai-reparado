package com.zunevio.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zunevio.ai.ui.theme.*

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Chat : Screen("chat", "Chat", Icons.Default.Chat)
    object Memoria : Screen("memoria", "Memoria", Icons.Default.Lightbulb)
    object Fotos : Screen("fotos", "Fotos", Icons.Default.Image)
    object Cesta : Screen("cesta", "Cesta", Icons.Default.ShoppingBag)
    object Agenda : Screen("agenda", "Agenda", Icons.Default.CalendarToday)
    object Planes : Screen("planes", "Planes", Icons.Default.WorkspacePremium)
    object Perfil : Screen("perfil", "Perfil", Icons.Default.Person)
    object Referidos : Screen("referidos", "Referidos", Icons.Default.Share)
}

@Composable
fun BottomNavBar(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    val items = listOf(
        Screen.Chat,
        Screen.Memoria,
        Screen.Fotos,
        Screen.Cesta,
        Screen.Agenda,
        Screen.Planes
    )

    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(CardBackground)
            .border(1.dp, CardBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        containerColor = CardBackground,
        tonalElevation = 8.dp
    ) {
        items.forEach { screen ->
            val selected = currentRoute == screen.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(screen.route) },
                icon = {
                    Icon(
                        imageVector = screen.icon,
                        contentDescription = screen.title,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = screen.title,
                        fontSize = 10.sp,
                        color = if (selected) ZunevioCyan else TextSlate400
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ZunevioCyan,
                    unselectedIconColor = TextSlate400,
                    indicatorColor = CardBackground
                )
            )
        }
    }
}

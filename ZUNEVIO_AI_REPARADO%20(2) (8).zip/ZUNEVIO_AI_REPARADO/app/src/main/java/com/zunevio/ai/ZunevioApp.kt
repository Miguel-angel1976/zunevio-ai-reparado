package com.zunevio.ai

import android.app.Application
import com.google.firebase.FirebaseApp

class ZunevioApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Inicializa el SDK de Firebase automáticamente usando google-services.json
        FirebaseApp.initializeApp(this)
    }
}

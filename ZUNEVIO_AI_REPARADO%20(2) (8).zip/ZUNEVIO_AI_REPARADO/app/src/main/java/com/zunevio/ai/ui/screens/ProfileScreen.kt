package com.zunevio.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.zunevio.ai.data.model.UserProfile
import com.zunevio.ai.ui.theme.*

@Composable
fun ProfileScreen(
    userProfile: UserProfile?,
    onSignOut: () -> Unit
) {
    val auth = FirebaseAuth.getInstance()
    val isGuest = userProfile?.isAnonymous ?: true

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Avatar
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(CardBackground),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Person, contentDescription = null, tint = ZunevioCyan, modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = userProfile?.displayName ?: "Usuario Invitado",
            color = TextWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = if (isGuest) "Modo Invitado (Sin registro)" else (userProfile?.email ?: ""),
            color = TextSlate400,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Tarjeta de Estado de Cuenta
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Plan activo:", color = TextSlate400, fontSize = 13.sp)
                    Text(
                        if (userProfile?.plan == "premium") "Premium" else "Estándar (Gratuito)",
                        color = if (userProfile?.plan == "premium") CrownGoldMain else ZunevioCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Créditos disponibles:", color = TextSlate400, fontSize = 13.sp)
                    Text("${userProfile?.credits ?: 20}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Cuota diaria gratuita:", color = TextSlate400, fontSize = 13.sp)
                    Text("20 créditos / 24h", color = TextSlate200, fontSize = 13.sp)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Amigos recomendados:", color = TextSlate400, fontSize = 13.sp)
                    Text("${userProfile?.validReferrals ?: 0} amigos", color = TextSlate200, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tarjeta de Seguridad y Privacidad
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = GreenSuccess, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Seguridad y Aislamiento de Datos", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Tus datos están protegidos con reglas de seguridad Firestore aisladas por UID.", color = TextSlate400, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Botón Cerrar Sesión
        Button(
            onClick = onSignOut,
            modifier = Modifier.fillMaxWidth().height(46.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CardBackground)
        ) {
            Icon(Icons.Default.ExitToApp, contentDescription = null, tint = RedDanger, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Cerrar Sesión", color = RedDanger, fontWeight = FontWeight.Bold)
        }
    }
}

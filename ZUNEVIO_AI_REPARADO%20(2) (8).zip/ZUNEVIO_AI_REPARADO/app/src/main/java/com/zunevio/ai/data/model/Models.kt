package com.zunevio.ai.data.model

import com.google.gson.annotations.SerializedName

/**
 * Perfil de usuario ZUNEVIO AI sincronizado exactamente con Firestore
 * Colección: users/{uid}
 */
data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val photoUrl: String = "",
    val plan: String = "standard", // "standard" | "premium"
    val credits: Int = 20,
    val dailyCreditsQuota: Int = 20,
    val validReferrals: Int = 0,
    val referralCode: String = "",
    val isAnonymous: Boolean = false
)

/**
 * Mensaje individual del chat ZUNEVIO AI
 */
data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: String = "user", // "user" | "assistant"
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val sources: List<WebSource> = emptyList(),
    val isStreaming: Boolean = false
)

data class WebSource(
    val title: String = "",
    val uri: String = ""
)

/**
 * Petición al endpoint seguro /api/chat del backend
 */
data class ChatApiRequest(
    @SerializedName("message") val message: String,
    @SerializedName("history") val history: List<ChatHistoryItem> = emptyList(),
    @SerializedName("searchWeb") val searchWeb: Boolean = false,
    @SerializedName("autoMemory") val autoMemory: Boolean = true,
    @SerializedName("model") val model: String = "gemini-3.8-flash"
)

data class ChatHistoryItem(
    @SerializedName("role") val role: String,
    @SerializedName("content") val content: String
)

data class ChatApiResponse(
    @SerializedName("reply") val reply: String,
    @SerializedName("sources") val sources: List<WebSource>? = null,
    @SerializedName("creditsRemaining") val creditsRemaining: Int? = null,
    @SerializedName("plan") val plan: String? = null
)

/**
 * Memoria persistente privada
 * Colección: users/{uid}/memories
 */
data class MemoryItem(
    val id: String = "",
    val text: String = "",
    val category: String = "general",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Cesta de la compra inteligente
 * Colección: users/{uid}/cesta
 */
data class CestaItem(
    val id: String = "",
    val name: String = "",
    val completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Agenda de eventos y citas
 * Colección: users/{uid}/agenda
 */
data class AgendaEvent(
    val id: String = "",
    val title: String = "",
    val dateTime: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Foto generada en el estudio
 * Colección: users/{uid}/photos
 */
data class PhotoItem(
    val id: String = "",
    val prompt: String = "",
    val imageUrl: String = "",
    val aspectRatio: String = "1:1",
    val style: String = "realista",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Creación de sesión segura de pago con Stripe
 */
data class StripeCheckoutRequest(
    @SerializedName("priceId") val priceId: String,
    @SerializedName("mode") val mode: String = "subscription" // "subscription" | "payment"
)

data class StripeCheckoutResponse(
    @SerializedName("url") val url: String,
    @SerializedName("sessionId") val sessionId: String
)

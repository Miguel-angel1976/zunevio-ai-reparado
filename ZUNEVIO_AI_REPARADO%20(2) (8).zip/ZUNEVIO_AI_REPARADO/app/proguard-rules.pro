# ==============================================================================
# Reglas de Optimización ProGuard / R8 para ZUNEVIO AI Android (Release)
# ==============================================================================

# 1. Preservar atributos de depuración y reflexión en la traza de errores
# Permite identificar números de línea reales y nombres de clases en Google Play Console
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# 2. Preservar excepciones y errores para evitar ofuscación críptica (evita clases como L2.i)
-keepclassmembers class * extends java.lang.Throwable {
    <fields>;
    <methods>;
}

# 3. Modelos de Datos & Serialización Gson
# Impide que R8 ofusque o elimine los campos mapeados con el backend o Firestore
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
    @com.google.gson.annotations.Expose <fields>;
}
-keep class com.zunevio.ai.data.model.** { *; }

# 4. Cliente de Red Retrofit & OkHttp
-dontwarn okhttp3.**
-dontwarn retrofit2.**
-dontwarn javax.annotation.**
-keepclassmembers interface * {
    @retrofit2.http.* <methods>;
}
-keep class retrofit2.** { *; }
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations

# 5. Concurrencia y Corrutinas de Kotlin
# Garantiza que el manejador de excepciones y despachadores no se eliminen en Release
-keepclassmembers class kotlinx.coroutines.internal.MainDispatcherFactory {
    public <init>();
}
-keepclassmembers class kotlinx.coroutines.CoroutineExceptionHandler {
    public <init>();
}
-keepclassmembers class * extends kotlinx.coroutines.CoroutineScope { *; }
-dontwarn kotlinx.coroutines.**

# 6. Firebase Authentication & Executors Asíncronos
# Preserva hilos y ejecutores de CustomThreadFactory y llamadas de autenticación
-keep class com.google.firebase.concurrent.** { *; }
-keep class com.google.firebase.auth.** { *; }
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**

# 7. Cloud Firestore, gRPC y Protocol Buffers
# Necesario para la transmisión HTTP/2 y sincronización de snapshots en tiempo real
-keep class com.google.firebase.firestore.** { *; }
-keep class io.grpc.** { *; }
-dontwarn io.grpc.**
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.protobuf.**

# 8. Jetpack Compose UI
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**

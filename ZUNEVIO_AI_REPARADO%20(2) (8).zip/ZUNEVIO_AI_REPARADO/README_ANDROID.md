# ZUNEVIO AI — Aplicación Android Nativa Oficial

Esta carpeta contiene la aplicación Android nativa completa y lista para producción de **ZUNEVIO AI**, desarrollada en **Kotlin** y **Jetpack Compose**.

---

## 1. Características Técnicas

* **Lenguaje:** Kotlin 2.1
* **Interfaz de Usuario:** Jetpack Compose (Material 3)
* **SDK:** Target SDK 36 (Android 16), Min SDK 26 (Android 8.0 Oreo)
* **Arquitectura:** MVVM + Clean Repository Pattern + Kotlin Coroutines & Flow
* **Seguridad:**
  * **Sin credenciales privadas en el cliente:** La app se comunica con el backend seguro de ZUNEVIO AI (`https://zunevio-ai.ai.studio/api/`) mediante tokens JWT Bearer de Firebase Authentication.
  * Claves secretas de Stripe y Gemini permanecen estrictamente protegidas en el backend existente.

---

## 2. Integración y Sincronización con la Web

La aplicación Android comparte exactamente la misma infraestructura que la versión web:

1. **Mismas Cuentas y Autenticación:** Firebase Authentication (mismo proyecto de Firebase).
2. **Misma Base de Datos:** Cloud Firestore (`users/{uid}`, `memories`, `cesta`, `agenda`, `chats`).
3. **Mismos Créditos y Planes:** 20 créditos diarios gratis renovables en Plan Estándar; Plan Premium con 500 créditos y pagos procesados por Stripe.
4. **Mismo Backend Gemini:** Respuestas en tiempo real con Google Search Grounding y razonamiento avanzado.

---

## 3. Estructura del Proyecto Creado

```
android/
├── build.gradle.kts                   # Configuración raíz de plugins Gradle
├── settings.gradle.kts                # Repositorios y módulos incluidos (:app)
├── gradle/
│   ├── libs.versions.toml             # Catálogo de versiones centralizado (Kotlin, Compose, Firebase)
│   └── wrapper/
│       └── gradle-wrapper.properties  # Gradle 8.11.1
└── app/
    ├── build.gradle.kts               # Configuración del módulo Android (SDK 36, dependencias)
    ├── proguard-rules.pro             # Reglas de ofuscación y optimización
    └── src/main/
        ├── AndroidManifest.xml        # Manifiesto y permisos (Internet, Audio)
        ├── res/                       # Recursos XML (colores espaciales, temas oscuros, strings)
        └── java/com/zunevio/ai/
            ├── ZunevioApp.kt          # Inicialización de Firebase
            ├── MainActivity.kt        # Actividad principal con navegación Compose
            ├── data/
            │   ├── model/Models.kt    # Modelos de datos compartidos con Firestore y backend
            │   ├── api/ZunevioApiService.kt # Cliente Retrofit con interceptor Bearer Token
            │   └── repository/ZunevioRepository.kt # Sincronización en tiempo real de Firestore
            └── ui/
                ├── theme/             # Colores oficiales (#020511, azul eléctrico, dorado)
                ├── components/        # TopBar, BottomNavBar, Coronas Doradas 3D
                └── screens/           # Pantallas: Chat, Memoria, Cesta, Agenda, Planes, Referidos, Perfil
```

---

## 4. Cómo Abrir y Compilar en Android Studio

1. Abre **Android Studio** (versión Ladybug, Meerkat o superior).
2. Selecciona **Open** y navega hasta la carpeta `android/` de este proyecto.
3. Espera a que Gradle sincronice las dependencias automáticamente.
4. Descarga tu archivo `google-services.json` desde la Consola de Firebase del proyecto ZUNEVIO AI y colócalo en `android/app/google-services.json`.

---

## 5. Cómo Generar el APK de Prueba (Debug)

Desde la terminal en la carpeta `android/`:
```bash
./gradlew assembleDebug
```
* **Archivo generado:** `android/app/build/outputs/apk/debug/app-debug.apk`
* Puedes transferir e instalar este archivo directamente en cualquier dispositivo Android con la opción "Instalar aplicaciones desconocidas" habilitada.

---

## 6. Cómo Generar el Android App Bundle (.AAB) para Google Play

Desde la terminal en la carpeta `android/`:
```bash
./gradlew bundleRelease
```
* **Archivo generado:** `android/app/build/outputs/bundle/release/app-release.aab`
* Este es el archivo oficial listo para subir a **Google Play Console** en la sección de Pruebas Internas, Cerradas o Producción.
